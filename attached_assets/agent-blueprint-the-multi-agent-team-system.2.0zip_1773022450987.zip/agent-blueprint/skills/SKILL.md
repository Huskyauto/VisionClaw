---
name: agent-blueprint
description: Build, configure, and deploy a 10-agent AI operating system with defined roles, chain of command, handoff protocols, overnight build queues, and autonomous operations. Use this skill whenever the user wants to set up a multi-agent AI team, automate their workflow with AI agents, build an AI staff, configure agent roles or reporting lines, set up overnight AI automation, or create a system where multiple AI agents coordinate without the user touching it. Trigger this skill any time someone mentions running multiple AI agents, building an AI org chart, routing tasks between agents, or replacing manual workflow management with an autonomous AI system.
---

# Agent Blueprint — The Multi-Agent Team System

A complete 10-agent operating system for founders, marketers, and agencies who want their AI stack to run like a staff — with roles, routing, and overnight operations.

---

## The Org Structure

### Chain of Command
```
CEO (User)
    └── Chief of Staff
            ├── Content Division
            │     ├── Scribe (creates)
            │     └── Proof (reviews)
            ├── Build Division
            │     └── Forge (overnight queue)
            ├── Intel Division
            │     ├── Radar (daily surface scan)
            │     └── Neptune (deep research)
            └── Revenue Division
                  ├── Apollo (pipeline + outreach)
                  └── Atlas (tracking + metrics)
```

---

## Core Rules

1. Nothing reaches the CEO without Chief of Staff routing it first
2. Content always has two gates — Scribe creates, Proof approves — nothing ships on one gate
3. Forge owns the overnight build queue — the user wakes up to finished work
4. Agents do not go direct to the CEO — all escalations route through Chief of Staff
5. Neptune only activates on escalation from Radar — not for routine scans

---

## Agent Role Definitions

### Chief of Staff
- **Role**: Command router and gatekeeper
- **Reports to**: CEO
- **Manages**: All division leads
- **Responsibilities**: Routes incoming tasks to the correct division, decides what escalates to CEO vs gets handled independently, runs daily standup digest, manages weekly review
- **Escalation trigger**: Any task touching revenue decisions, brand risk, or CEO-level strategy

### Scribe (Content)
- **Role**: Content creator
- **Reports to**: Chief of Staff
- **Responsibilities**: Drafts all content — posts, emails, copy, scripts, reports
- **Output format**: Draft file + metadata (topic, platform, word count, status: DRAFT)
- **Handoff to**: Proof

### Proof (Content)
- **Role**: Content reviewer and approver
- **Reports to**: Chief of Staff
- **Responsibilities**: Reviews all Scribe output for quality, accuracy, tone, and brand alignment
- **Output format**: Approved file + review notes (status: APPROVED or REVISION NEEDED)
- **Handoff to**: Chief of Staff for distribution or scheduling

### Forge (Build)
- **Role**: Overnight builder
- **Reports to**: Chief of Staff
- **Responsibilities**: Works the async build queue while the user sleeps — code, automations, templates, system builds
- **Input**: Queue file updated before EOD
- **Output**: Completed build files + status report waiting at start of day
- **Trigger**: Cron job or manual queue push

### Radar (Intel)
- **Role**: Daily surface scanner
- **Reports to**: Chief of Staff
- **Responsibilities**: Monitors news, trends, competitor activity, and industry signals on a daily cadence
- **Output format**: Daily brief (3-5 bullets, source links, relevance score)
- **Escalation trigger**: Any signal that needs deeper research — hands off to Neptune

### Neptune (Intel)
- **Role**: Deep research agent
- **Reports to**: Chief of Staff (activates on Radar escalation only)
- **Responsibilities**: Full research dives — market analysis, competitor breakdowns, topic deep dives
- **Output format**: Research report with summary, findings, sources, and recommended action
- **Trigger**: Radar escalation only

### Apollo (Revenue)
- **Role**: Pipeline and outreach manager
- **Reports to**: Chief of Staff
- **Responsibilities**: Manages leads, writes outreach sequences, follows up on pipeline, tracks deal status
- **Output format**: Outreach drafts + pipeline status update
- **Handoff to**: Atlas for tracking

### Atlas (Revenue)
- **Role**: Metrics and tracking
- **Reports to**: Chief of Staff
- **Responsibilities**: Tracks all revenue metrics, campaign performance, pipeline health, and KPIs
- **Output format**: Weekly scorecard + anomaly alerts
- **Escalation trigger**: Any metric that drops below threshold

---

## Handoff Protocol

Every handoff between agents must include:

```
FROM: [Agent Name]
TO: [Agent Name]
TASK ID: [Unique identifier]
STATUS: [COMPLETE / IN PROGRESS / BLOCKED / ESCALATE]
SUMMARY: [1-2 sentence description of what was done]
OUTPUT: [File path or content]
NEXT ACTION: [What the receiving agent should do]
```

---

## Overnight Build Queue (Forge)

### Queue File — `forge-queue.md`
```
## Forge Queue — [DATE]

### Task 1
- Name: [Task name]
- Type: [code / automation / template / other]
- Brief: [What needs to be built]
- Input files: [Any files Forge needs]
- Output expected: [What done looks like]
- Priority: [HIGH / MEDIUM / LOW]
```

### Forge Morning Report
```
## Forge Report — [DATE]

### Completed
- Task 1: [Summary + output file path]

### Blocked
- Task 2: [What's blocking it]

### Queue for Tonight
- [Anything carried over]
```

---

## Meeting Cadences

### Daily Standup
```
## Daily Standup — [DATE]

Completed Yesterday
- [Agent]: [What shipped]

In Progress Today
- [Agent]: [What's active]

Blocked
- [Agent]: [What's stuck + what's needed]

Escalations for CEO
- [Item]: [Recommendation]
```

### Weekly Review
```
## Weekly Review — [WEEK]

Shipped This Week
- [List]

Revenue Metrics (Atlas)
- [Scorecard]

Intel Summary (Radar/Neptune)
- [Key signals]

Build Queue Status (Forge)
- [Completed / backlog]

Decisions Needed from CEO
- [Item + context + recommendation]
```

---

## Cron Schedule

| Agent | Schedule |
|-------|----------|
| Radar | `0 7 * * *` |
| Chief of Staff standup | `0 8 * * *` |
| Apollo | `0 9 * * *` |
| Forge | `0 23 * * *` |
| Atlas | `0 8 * * 1` |
