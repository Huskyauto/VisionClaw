# HEARTBEAT.md — Agent Blueprint

## Autonomous Operations

These tasks run without being asked. Configure your cron schedules below.

---

## Cron Schedule

| Agent | Task | Schedule | Output |
|-------|------|----------|--------|
| Radar | Daily surface scan | `0 7 * * *` (7:00 AM daily) | `/intel/daily/radar-[DATE].md` |
| Chief of Staff | Daily standup digest | `0 8 * * *` (8:00 AM daily) | Delivered to CEO |
| Apollo | Pipeline check + outreach | `0 9 * * *` (9:00 AM daily) | `/revenue/pipeline.md` update |
| Forge | Overnight build queue | `0 23 * * *` (11:00 PM daily) | `/builds/output/` + morning report |
| Atlas | Weekly scorecard | `0 8 * * 1` (Monday 8:00 AM) | `/revenue/metrics/atlas-[WEEK].md` |

---

## What Each Heartbeat Does

### Radar — 7:00 AM Daily
1. Scans configured topics (news, competitors, industry signals)
2. Compiles 3-5 bullet brief with source links and relevance score
3. Saves to `/intel/daily/`
4. If anything warrants deeper research, escalates to Neptune automatically

### Chief of Staff — 8:00 AM Daily
1. Pulls completed tasks from overnight
2. Checks active handoffs
3. Reviews Forge morning report
4. Compiles standup digest
5. Delivers to CEO — only flags what actually needs attention

### Apollo — 9:00 AM Daily
1. Reviews pipeline status
2. Identifies follow-ups due today
3. Drafts any outreach needed
4. Updates pipeline log

### Forge — 11:00 PM Daily
1. Reads `forge-queue.md`
2. Works through queue in priority order
3. Saves completed builds to `/builds/output/`
4. Writes morning report to `/builds/reports/`
5. CEO wakes up to finished work

### Atlas — Monday 8:00 AM
1. Pulls all revenue metrics from the past week
2. Compares to baseline and prior week
3. Flags any anomalies
4. Delivers scorecard to Chief of Staff
5. Chief of Staff includes in Monday standup

---

## Proactive Notifications

The system sends unprompted alerts for:

- Radar escalation to Neptune (immediate)
- Atlas metric below threshold (immediate)
- Forge queue empty at EOD (reminder to CEO at 9:00 PM)
- Content stuck in Proof for more than 24 hours (flag to Chief of Staff)
- Any agent blocked on a task (flag in next standup)

---

## Configuring Radar Topics

Edit `radar-config.md` to set what Radar monitors:

```
## Radar Config

Topics:
- [Your industry]
- [Competitor names]
- [Keywords relevant to your business]
- [Trend areas to watch]

Sources (optional):
- [Specific publications or sites]
```
