# TOOLS.md — Agent Blueprint

## Primary Tools by Agent

---

### Chief of Staff
**Tool:** Task router + memory
- Reads incoming requests and maps them to the correct agent
- Maintains daily log and standup digest
- No external API required — runs on core model

---

### Scribe
**Tool:** Claude (content generation)
- Drafts all content based on brief from Chief of Staff
- Outputs to `/content/drafts/` with task ID
- Format: `content-[ID].md`
- Handoff triggers automatically on completion

---

### Proof
**Tool:** Claude (review) + optional Grammarly API
- Reviews Scribe output for tone, quality, brand alignment
- Returns APPROVED or REVISION NEEDED with notes
- `GRAMMARLY_API_KEY=YOUR_API_KEY_HERE` (optional)

---

### Forge
**Tool:** Claude Code / any code execution environment
- Reads from `forge-queue.md` nightly
- Outputs completed builds to `/builds/output/`
- Morning report saved to `/builds/reports/forge-[DATE].md`

---

### Radar
**Tool:** Perplexity API or Claude + web search
- Runs daily surface scan on configured topics
- Topics stored in `radar-config.md`
- Output: `/intel/daily/radar-[DATE].md`
- `PERPLEXITY_API_KEY=YOUR_API_KEY_HERE`

---

### Neptune
**Tool:** Perplexity Pro or Claude + deep research
- Activates on Radar escalation only
- Full research report saved to `/intel/research/neptune-[DATE]-[TOPIC].md`
- `PERPLEXITY_API_KEY=YOUR_API_KEY_HERE`

---

### Apollo
**Tool:** Clay, Apollo.io, or Claude + CRM
- Manages lead list in `/revenue/pipeline.md`
- Outreach drafts saved to `/revenue/outreach/`
- `CRM_API_KEY=YOUR_API_KEY_HERE`

---

### Atlas
**Tool:** Notion, Airtable, or Claude + spreadsheet
- Weekly scorecard saved to `/revenue/metrics/atlas-[WEEK].md`
- Anomaly alerts routed to Chief of Staff immediately
- `NOTION_API_KEY=YOUR_API_KEY_HERE`
- `AIRTABLE_API_KEY=YOUR_API_KEY_HERE`

---

## File Structure

```
$WORKSPACE/
├── content/
│   ├── drafts/
│   └── approved/
├── builds/
│   ├── queue/forge-queue.md
│   ├── output/
│   └── reports/
├── intel/
│   ├── daily/
│   └── research/
├── revenue/
│   ├── pipeline.md
│   ├── outreach/
│   └── metrics/
└── logs/
    └── daily-log.md
```

---

## CLI Notes

- Forge runs as a background process on cron
- Use `tail -f logs/daily-log.md` to monitor activity
- All agent outputs append to `logs/daily-log.md` automatically
- Exec timeout default: 30s for routing tasks, 300s for Forge builds
