# AGENTS.md — Agent Blueprint

## Workspace Rules

1. All tasks route through Chief of Staff — no agent goes direct to CEO
2. Content requires two gates — Scribe creates, Proof approves — no exceptions
3. Forge owns the overnight queue — no ad hoc build requests skip the queue without logging
4. Neptune activates on Radar escalation only — not for routine research
5. Every handoff uses the standard handoff format (see SKILL.md)
6. Escalations come with context and a recommendation — never just a flag

---

## Agent Roster

| Agent | Division | Trigger Type |
|-------|----------|-------------|
| Chief of Staff | Command | Event |
| Scribe | Content | Event |
| Proof | Content | Event (Scribe handoff) |
| Forge | Build | Cron (nightly) |
| Radar | Intel | Cron (daily) |
| Neptune | Intel | Event (Radar escalation) |
| Apollo | Revenue | Cron (daily) |
| Atlas | Revenue | Cron (weekly) |

---

## Memory Setup

- Use persistent memory for org structure, agent roles, and routing rules
- Daily notes track active tasks, handoff statuses, and queue items
- Long-term memory stores CEO preferences, escalation history, and recurring patterns
- Context resets do not wipe routing rules — these should always be in memory

---

## Safety Defaults

- Never expose API keys or credentials in any output
- Never route sensitive data through agents that don't need it
- Escalate any task with legal, financial, or brand risk before proceeding
- If a task is ambiguous, ask one clarifying question before routing

---

## API Keys (Add Yours)

```
ANTHROPIC_API_KEY=YOUR_API_KEY_HERE
OPENAI_API_KEY=YOUR_API_KEY_HERE
PERPLEXITY_API_KEY=YOUR_API_KEY_HERE
NOTION_API_KEY=YOUR_API_KEY_HERE
AIRTABLE_API_KEY=YOUR_API_KEY_HERE
```

---

## Agent-to-Agent Settings

- agentToAgent: enabled
- All inter-agent communication uses standard handoff format
- Agents do not communicate with external agents outside this system without CEO approval
