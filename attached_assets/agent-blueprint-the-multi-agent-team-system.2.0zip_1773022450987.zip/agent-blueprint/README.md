# Agent Blueprint — The Multi-Agent Team System

**Role:** Multi-Agent System
**Tagline:** Wake up to finished work. 10 agents handling content, research, builds, and revenue — automatically.
**Category:** Productivity
**Price:** $19

---

## What's Included

- `README.md` — You're reading it
- `IDENTITY.md` — Name, role, vibe, expertise
- `SOUL.md` — Voice, tone, personality, boundaries
- `AGENTS.md` — Workspace rules, memory setup, safety defaults
- `MEMORY.md` — Operating patterns, preferences, tacit knowledge
- `TOOLS.md` — Tool configurations and workflows
- `HEARTBEAT.md` — Recurring tasks and autonomous operations
- `skills/SKILL.md` — Full 10-agent system blueprint

---

## What This Is

Agent Blueprint is a complete 10-agent operating system. It gives your AI stack a real org structure — roles, reporting lines, handoff protocols, and overnight operations. You stop managing tasks and start running a team.

The 10 agents:

```
CEO (You)
    └── Chief of Staff
            ├── Content: Scribe + Proof
            ├── Build: Forge
            ├── Intel: Radar + Neptune
            └── Revenue: Apollo + Atlas
```

---

## Quick Start (5 minutes)

1. Unzip this folder into your OpenClaw workspace
2. Open `IDENTITY.md` and confirm the agent name and role
3. Open `AGENTS.md` and add your API keys where marked
4. Open `HEARTBEAT.md` and set your cron schedules
5. Ask your agent: *"Describe your team structure"* — if it walks you through the org chart, you're live

---

## Full Setup (30 minutes)

1. Complete steps above
2. Open `TOOLS.md` and configure each integration
3. Open `MEMORY.md` and add your preferences
4. Install the skill from `skills/SKILL.md`
5. Run the verification checklist below

---

## Verification Checklist

- [ ] Ask: *"How would you describe yourself?"* — should reference the 10-agent system
- [ ] Ask: *"Walk me through the chain of command"* — should match the org chart
- [ ] Ask: *"What does Forge do?"* — should describe overnight build queue
- [ ] Ask: *"Set up tonight's Forge queue"* — should return the queue format
- [ ] Ask: *"Give me today's standup"* — should return standup format

---

## Troubleshooting

**Agent doesn't know its structure** — Re-load `IDENTITY.md` and `SOUL.md` into context

**Forge queue not running** — Check cron config in `HEARTBEAT.md`

**Handoffs getting lost** — Confirm agents are using the handoff format in `SKILL.md`

**Agent going direct to CEO** — Remind it of Rule 1: everything routes through Chief of Staff

---

## Version Info

- Export Date: 2026-03-02
- Package: agent-blueprint-the-multi-agent-team-system.zip
