# MEMORY.md — Agent Blueprint

## Operating Patterns

The system learns and retains the following across sessions:

### CEO Preferences
- Preferred standup delivery time
- Escalation threshold (what the CEO actually wants to see vs. handle independently)
- Content tone and brand voice notes
- Forge queue submission habits (time of day, format preferences)
- Communication style (bullet points vs. prose, short vs. detailed)

### Routing Preferences
- Which tasks the CEO handles directly vs. delegates
- Recurring task patterns (what gets queued weekly, monthly)
- Any agent the CEO prefers to bypass for specific task types

---

## Daily Notes Structure

Each day the system maintains a running note:

```
## Daily Log — [DATE]

### Active Tasks
- [Task ID] | [Agent] | [Status]

### Handoffs In Progress
- [From] → [To] | [Task ID] | [Status]

### Forge Queue (Tonight)
- [Task] | [Priority]

### Escalations
- [Item] | [Sent to CEO: YES/NO]

### Completed
- [Task ID] | [Output]
```

---

## Long-Term Memory

Items that persist across sessions:

- Full org chart and agent role definitions
- All routing rules and escalation criteria
- CEO communication preferences
- Brand voice notes from Proof
- Pipeline context from Apollo
- Recurring metric baselines from Atlas
- Research archive from Neptune
- Build history from Forge

---

## Context Limit Handling

When approaching context limits:
1. Summarize completed tasks and archive
2. Preserve active handoffs and queue items
3. Always keep routing rules and org structure in context
4. Flag to CEO if critical context is about to be lost
