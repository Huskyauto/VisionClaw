# Content Production Workflow

Multi-agent system for creating Claw Mart blog content.

## Agents

### 1. Research Agent
- **Model:** `grok-4` (via direct XAI API)
- **Method:** Direct API call (NOT subagent spawn — subagents don't get realtime search)
- **XAI Key:** From auth-profiles.json (`xai:default`)
- **API:** `https://api.x.ai/v1/chat/completions`
- **Job:** Find facts, examples, technical details, competitor content
- **Input:** Topic + angle
- **Output:** Research brief with sources, key facts, examples to include

### 2. SEO Agent  
- **Model:** `grok-4` (via direct XAI API)
- **Method:** Direct API call (NOT subagent spawn)
- **XAI Key:** From auth-profiles.json (`xai:default`)
- **API:** `https://api.x.ai/v1/chat/completions`
- **Job:** Keyword research, title optimization, meta suggestions
- **Input:** Topic + draft angle
- **Output:** Primary keyword, secondary keywords, title options, meta description

### 3. Drafting Agent
- **Model:** `anthropic/claude-opus-4.6`
- **Method:** Direct OpenRouter API call (NOT subagent spawn)
- **Job:** Write the actual post
- **Input:** Research brief + SEO brief + brand voice guidelines
- **Output:** Complete blog post draft
- **Critical:** Set `max_tokens: 8000` minimum—technical posts need room

## Workflow

```
┌─────────────┐
│   Context   │ ← You give me the topic/angle
└──────┬──────┘
       │
       ▼
┌─────────────┐     ┌─────────────┐
│  Research   │────→│  Research   │
│   Agent     │     │   Brief     │
└─────────────┘     └──────┬──────┘
                           │
       ┌───────────────────┘
       ▼
┌─────────────┐     ┌─────────────┐
│  SEO Agent  │────→│  SEO Brief  │
└─────────────┘     └──────┬──────┘
                           │
       ┌───────────────────┘
       ▼
┌─────────────┐     ┌─────────────┐
│  Drafting   │────→│  Blog Post  │
│   Agent     │     │   Draft     │
└─────────────┘     └─────────────┘
```

## How I Use Them

I spawn each agent as an isolated session with their specific model:

```
sessions_spawn(
  task="Research this topic...",
  model="x-ai/grok-4.1-fast"
)
```

They run in parallel, then I hand off their outputs to the next stage.

## Brand Voice Injection

Every agent gets the BRAND_VOICE.md guidelines:
- Practical over philosophical
- No fluff
- SEO + sharable
- "How to X with OpenClaw" format

## Example: Voice Chat Article

1. **Research Agent** finds:
   - ElevenLabs pricing tiers
   - Deepgram accuracy benchmarks  
   - Browser MediaRecorder compatibility
   - Tailscale setup quirks

2. **SEO Agent** returns:
   - Primary: "voice chat openclaw"
   - Secondary: "openclaw voice", "ai voice interface"
   - Titles: "How to Voice Chat with Your OpenClaw", "Setting Up Voice Control for OpenClaw"

3. **Drafting Agent** writes the full post using research + SEO + brand voice

## Technical Implementation

### Running Research + SEO in Parallel

```javascript
// Both agents spawn simultaneously
sessions_spawn({
  task: "Research topic...",
  model: "openrouter/x-ai/grok-4.1-fast",
  label: "research-topic"
})

sessions_spawn({
  task: "SEO optimization...",
  model: "openrouter/x-ai/grok-4.1-fast", 
  label: "seo-topic"
})
```

### Drafting with Opus 4.6 (Direct API)

```bash
curl https://openrouter.ai/api/v1/chat/completions \
  -H "Authorization: Bearer $OPENROUTER_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "anthropic/claude-opus-4.6",
    "messages": [{"role": "user", "content": $PROMPT}],
    "max_tokens": 8000
  }'
```

**Why direct API for Opus?** Subagent spawning has stricter model allowlists. Opus 4.6 falls back to default when spawned as subagent. Direct API bypasses this restriction.

### Token Budget

**Default: 8000 tokens** for all posts to prevent truncation.

This ensures complete output for posts ranging from 1,000-3,000 words without needing to check or adjust per post.

## When to Skip Agents

- If you already gave me all the research (like the Voice Companion skill details), skip Research
- If SEO isn't critical for a post, skip SEO
- For quick edits/revisions, just use me directly

## Full Publishing Workflow

Complete process from research to live blog post:

### ⚠️ CRITICAL: Never Change Slugs After Publishing
Changing slugs breaks existing links and hurts SEO. Once a post is live, keep the slug the same.

### ⚠️ CRITICAL: NEVER Write Blog Posts Yourself
You are a content marketing assistant, NOT a writer. You MUST always use Opus 4.6 for drafting:
- Spawn the drafting agent (direct OpenRouter API call)
- Never write blog post content yourself
- If the API call fails or times out, STOP and tell the user immediately
- Do not attempt to write the post manually as a fallback

### 1. Research Phase
- Spawn Research Agent (`openrouter/x-ai/grok-4.1-fast`)
- Spawn SEO Agent (`openrouter/x-ai/grok-4.1-fast`) — parallel
- Collect: research brief + SEO brief

### 2. Drafting Phase
- Call Opus 4.6 directly via OpenRouter API
- Input: research + SEO + brand voice
- Output: complete markdown draft
- Token budget: 8000 (prevents truncation)

### 3. Hero Image Generation
**USE SKILL:** `skills/blog-image-generator/SKILL.md`

**Prompt Template:**
```
High-fidelity, glossy 3D rendering of [TOPIC]. A classic "Cyberpunk" or "Synthwave" gradient. Neon luminescence. Symmetrical and centered, typical of high-end hero images for websites.
```

**Technical:**
- Model: `gemini-3-pro-image-preview`
- Direct Google API (NOT OpenRouter — times out)
- Endpoint: `streamGenerateContent`
- Config: `aspectRatio: "16:9"`, `responseModalities: ["IMAGE", "TEXT"]`
- Extract base64 from streaming response

### 4. Publishing Phase
```bash
POST /api/v1/blog/posts
{
  "title": "...",           # Title goes here, NOT in content
  "slug": "...",
  "contentMarkdown": "...", # Body WITHOUT title - API adds it
  "excerpt": "...",
  "coverImageUrl": "...",
  "featuredListingIds": ["product-slug-1", "product-slug-2"],
  "published": true
}
```

**Critical:** Do NOT include the title in contentMarkdown — the API adds it automatically. Starting content with "# Title" duplicates it.

**Key:** Include `slug` for upsert (updates existing, creates new if absent)

## Output Locations

- Research briefs: `content/research/`
- SEO briefs: `content/seo/`
- Drafts: `content/drafts/`
- Final: `content/published/`
