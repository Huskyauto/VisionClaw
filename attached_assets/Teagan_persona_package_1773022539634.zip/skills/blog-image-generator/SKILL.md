# SKILL.md - Blog Post Hero Image Generator

## Description
Generate high-quality hero images for Claw Mart blog posts using Google Gemini 3 Pro Image Preview. Optimized for tech/software content with a distinctive cyberpunk/synthwave aesthetic.

## Prerequisites
- Google Gemini API key with Generative Language API access
- Environment variable: `GEMINI_API_KEY` or key stored in TOOLS.md

## Commands
- "Generate a hero image for [blog post topic]"
- "Create blog hero image about [subject]"

## Workflow

### 1. Construct the Prompt
Replace `[TOPIC]` in this template:

```
High-fidelity, glossy 3D rendering of [TOPIC DESCRIPTION]. A classic "Cyberpunk" or "Synthwave" gradient. Neon luminescence. Symmetrical and centered, typical of high-end hero images for websites.
```

**Examples by article type:**

**Coding/Development:**
> High-fidelity, glossy 3D rendering of a computer with an open coding terminal displaying code, with circular refresh arrows floating around it. A classic "Cyberpunk" or "Synthwave" gradient. Neon luminescence. Symmetrical and centered, typical of high-end hero images for websites.

**Email/Communication:**
> High-fidelity, glossy 3D rendering of a secure digital mailbox with glowing shields and encrypted message icons. A classic "Cyberpunk" or "Synthwave" gradient. Neon luminescence. Symmetrical and centered, typical of high-end hero images for websites.

**Memory/AI:**
> High-fidelity, glossy 3D rendering of a neural network visualization with interconnected nodes and flowing data streams. A classic "Cyberpunk" or "Synthwave" gradient. Neon luminescence. Symmetrical and centered, typical of high-end hero images for websites.

### 2. Generate Image via Google API

```bash
#!/bin/bash
set -e -E

GEMINI_API_KEY="$GEMINI_API_KEY"
MODEL_ID="gemini-3-pro-image-preview"
GENERATE_CONTENT_API="streamGenerateContent"

# Create request JSON
cat << EOF > request.json
{
  "contents": [{
    "role": "user",
    "parts": [{
      "text": "INSERT_PROMPT_HERE"
    }]
  }],
  "generationConfig": {
    "responseModalities": ["IMAGE", "TEXT"],
    "imageConfig": {
      "aspectRatio": "16:9",
      "imageSize": "1K"
    }
  }
}
EOF

# Call API
curl -X POST \
  -H "Content-Type: application/json" \
  "https://generativelanguage.googleapis.com/v1beta/models/${MODEL_ID}:${GENERATE_CONTENT_API}?key=${GEMINI_API_KEY}" \
  -d '@request.json'
```

### 3. Extract Image from Response

The response is a streaming JSON array. Extract base64 from the `inlineData` field:

```python
import json
import base64

def extract_image(response_path, output_path):
    with open(response_path, 'r') as f:
        data = json.load(f)
    
    # Handle streaming response (array of chunks)
    if isinstance(data, list):
        for chunk in data:
            for candidate in chunk.get('candidates', []):
                for part in candidate.get('content', {}).get('parts', []):
                    if 'inlineData' in part:
                        img_data = part['inlineData']['data']
                        with open(output_path, 'wb') as f:
                            f.write(base64.b64decode(img_data))
                        return output_path
    
    # Handle non-streaming response
    elif 'candidates' in data:
        for candidate in data['candidates']:
            for part in candidate.get('content', {}).get('parts', []):
                if 'inlineData' in part:
                    img_data = part['inlineData']['data']
                    with open(output_path, 'wb') as f:
                        f.write(base64.b64decode(img_data))
                    return output_path
    
    raise ValueError("No image found in response")
```

### 4. Upload to ClawMart

```bash
curl -X POST \
  -H "X-API-Key: $CLAWMART_API_KEY" \
  -F "image=@hero_image.png" \
  https://www.shopclawmart.com/api/v1/blog/images
```

Returns:
```json
{
  "url": "https://ltkehrsehoebzajkqrcp.supabase.co/storage/v1/object/public/blog-images/..."
}
```

## Key Technical Details

- **Model:** `gemini-3-pro-image-preview` (NOT flash or standard gemini-pro)
- **API Endpoint:** `streamGenerateContent` (streaming) or `generateContent` (non-streaming)
- **Aspect Ratio:** 16:9 for blog hero images
- **Image Size:** 1K (sufficient for web, fast generation)
- **Response Modality:** Must include both IMAGE and TEXT

## Prompt Template Variables

| Variable | Description | Example |
|----------|-------------|---------|
| `[TOPIC DESCRIPTION]` | What the 3D render should depict | "a computer with an open coding terminal" |
| `[MOOD/AESTHETIC]` | Usually "Cyberpunk" or "Synthwave" | "Cyberpunk" |

## Why This Works

1. **"High-fidelity, glossy 3D rendering"** — Forces quality, photorealistic 3D output
2. **"Classic Cyberpunk/Synthwave gradient"** — Establishes distinctive color palette (neon pinks, purples, blues)
3. **"Neon luminescence"** — Adds glow effects that make images pop
4. **"Symmetrical and centered"** — Professional composition suitable for hero banners
5. **"High-end hero images for websites"** — Frames the output expectation

## Common Pitfalls to Avoid

❌ **Don't use:** "Abstract illustration" — results in blurry, unfocused images
❌ **Don't use:** "Flat vector design" — Gemini 3 Pro excels at 3D renders
❌ **Don't use:** OpenRouter for this model — timeout issues, use direct Google API
✅ **Do use:** Specific 3D subject matter + cyberpunk aesthetic + symmetrical composition

## Example Full Workflow

```bash
# 1. Set keys
export GEMINI_API_KEY="$GEMINI_API_KEY..."
export CLAWMART_API_KEY="$CLAWMART_API_KEY..."

# 2. Create prompt
PROMPT='High-fidelity, glossy 3D rendering of a robotic claw hand holding a glowing smartphone. A classic "Cyberpunk" or "Synthwave" gradient. Neon luminescence. Symmetrical and centered, typical of high-end hero images for websites.'

# 3. Generate
cat << EOF > request.json
{
  "contents": [{"role": "user", "parts": [{"text": "$PROMPT"}]}],
  "generationConfig": {"responseModalities": ["IMAGE", "TEXT"], "imageConfig": {"aspectRatio": "16:9"}}
}
EOF

curl -s -X POST \
  -H "Content-Type: application/json" \
  "https://generativelanguage.googleapis.com/v1beta/models/gemini-3-pro-image-preview:streamGenerateContent?key=$GEMINI_API_KEY" \
  -d '@request.json' > response.json

# 4. Extract (using Python helper)
python3 extract_image.py response.json hero.png

# 5. Upload
curl -X POST \
  -H "X-API-Key: $CLAWMART_API_KEY" \
  -F "image=@hero.png" \
  https://www.shopclawmart.com/api/v1/blog/images
```

## Guardrails
- Never expose Gemini API key in chat output
- Always verify image quality before publishing
- Keep prompts centered/symmetrical for hero image use
- Use 16:9 aspect ratio for consistency with blog layout
