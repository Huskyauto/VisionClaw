# SKILL.md - ClawMart Creator

## Description
Create, manage, and publish ClawMart personas and skills, and download packages you own or purchased directly from OpenClaw chat.

## Prerequisites
- ClawMart creator account with an active subscription
- API key generated in ClawMart dashboard (API Keys tab)
- Environment variable set in OpenClaw: `CLAWMART_API_KEY=$CLAWMART_API_KEY...`

## Setup
1. Generate a ClawMart API key in your dashboard.
2. Store the key as `CLAWMART_API_KEY` in your OpenClaw environment/config.
3. Install this `SKILL.md` in your OpenClaw skills directory.
4. Reload OpenClaw and confirm this skill is available.

## Commands
- "Create a skill on ClawMart for [description]"
- "Create a persona on ClawMart for [description]"
- "Search ClawMart listings for [use case]"
- "Update my [listing name] on ClawMart"
- "Upload a new version of [listing name]"
- "Show my ClawMart listings"
- "Download my [listing or purchase] from ClawMart"
- "Show my purchasable/downloadable ClawMart packages"
- "Publish a blog post on ClawMart"
- "Update my ClawMart blog post [slug]"

## Workflow

### Standard Workflows

1. Confirm which workflow is requested: creator management, purchased download, or blog publishing.
2. Call `GET /me` first to validate identity/subscription.

### Listing Creation/Update
3. For listing creation/update:
   - Brainstorm ideas with the user before writing metadata.
   - Draft metadata and confirm required fields: name, tagline, about, category, capabilities, price, product type.
   - Call `POST /listings` to create drafts and `PATCH /listings/{id}` to revise.
4. Generate high-quality package files from your own capabilities:
   - Persona packages: `SOUL.md`, `MEMORY.md`, and supporting docs.
   - Skill packages: a complete `SKILL.md`.
5. Upload files with `POST /listings/{id}/versions`.

### Purchased/Owned Downloads
6. For purchased/owned downloads:
   - Call `GET /downloads` to list accessible packages.
   - Resolve the best match by id/slug/name from that list.
   - Call `GET /downloads/{idOrSlug}` to fetch the package content.

### Blog Post Publishing (Multi-Agent Workflow)

**Full automated workflow for creating and publishing blog posts:**

1. **Research Phase** (Grok 4.1-fast subagents):
   - Spawn Research agent: `sessions_spawn(model="openrouter/x-ai/grok-4.1-fast", task="Research topic...")`
   - Spawn SEO agent: `sessions_spawn(model="openrouter/x-ai/grok-4.1-fast", task="SEO optimization...")`
   - Both run in parallel
   - Collect: research brief + SEO brief (keywords, titles, structure)

2. **Drafting Phase** (Claude Opus 4.6):
   - Call Opus directly via OpenRouter API (NOT subagent)
   - Endpoint: `https://openrouter.ai/api/v1/chat/completions`
   - Model: `anthropic/claude-opus-4.6`
   - Prompt: research brief + SEO brief + BRAND_VOICE.md
   - **Token budget: 8000 (default)** — prevents truncation for 1,000-3,000 word posts
   - Output: complete blog post in markdown

3. **Hero Image Generation** (Google Gemini):
   - Use Google API directly: `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-exp-image-generation:generateContent`
   - Required: `"generationConfig": {"responseModalities": ["TEXT", "IMAGE"]}`
   - Extract base64 from `inlineData` field in response
   - Save as PNG

4. **Product Discovery** (ClawMart API):
   - Search listings: `GET /listings/search?q={topic}`
   - Find 3-5 relevant products to feature
   - Collect slugs for `featuredListingIds` array

5. **Publishing Phase** (ClawMart API):
   - Upload hero image: `POST /blog/images` (multipart form with image file)
   - Get back public URL from response
   - Create/update post: `POST /blog/posts` with:
     - `title`, `slug`, `contentMarkdown`
     - `coverImageUrl` (from image upload)
     - `featuredListingIds` (array of product slugs)
     - `tags`, `excerpt`, `published: true/false`
   - Returns: `publicUrl` for the live post

6. Before any publish action, ask for explicit user confirmation.
7. Summarize what was published and provide the live URL.

**Key Technical Details:**
- Opus 4.6 must use direct API (subagent spawning falls back to default model)
- Image generation requires `responseModalities: ["TEXT", "IMAGE"]` in generationConfig
- Featured products use `featuredListingIds` field (max 5 products)
- Blog posts upsert by slug (same slug updates existing post)

## API Reference
- Base URL: `https://shopclawmart.com/api/v1/`
- Auth header: `X-API-Key: ${CLAWMART_API_KEY}` (Note: uses X-API-Key, not Bearer)
- `GET /me` - creator profile and subscription state
- `GET /listings` - list creator listings
- `GET /listings/search` - search active listings by query (supports `q`, `type`, `limit`)
- `POST /listings` - create listing metadata
- `PATCH /listings/{id}` - update listing metadata
- `DELETE /listings/{id}` - unpublish/delete listing
- `POST /listings/{id}/versions` - upload package version (multipart or base64 JSON)
- `GET /downloads` - list all downloads you can access (created + purchased, including paid skills)
- `GET /downloads/{idOrSlug}` - download package content for an owned/purchased listing

### Blog Publishing (Admin Endpoints)
- `POST /blog/images` - upload image, returns URL for use in posts
- `POST /blog/posts` - create or update blog post (upserts by slug)

**POST /blog/posts Request Body:**

Required fields:
- `title` (string) - post title
- `contentMarkdown` (string) - post content in Markdown
- `coverImageUrl` (string) - absolute https URL or root-relative path like `/images/x.png`
- `content` (string) - alias for contentMarkdown

Optional fields:
- `slug` (string) - lowercase letters/numbers/hyphens; auto-generated from title if omitted
- `excerpt` (string) - auto-generated from content if omitted
- `featuredListingIds` (array) - product/listing slugs or ids, max 5
- `tags` (array or comma-separated string) - max 12 tags
- `authorName` (string) - default: "Claw Mart Team"
- `authorRole` (string) - author title/role
- `seoTitle` (string) - truncated to 70 chars
- `seoDescription` (string) - truncated to 180 chars
- `canonicalUrl` (string) - absolute https URL
- `published` (boolean) - default: true
- `publishedAt` (date string) - if omitted and published=true, uses current time

**Note:** Endpoint requires admin auth. Returns 403 if key lacks admin access.

## Guardrails
- Never expose raw API keys in chat output.
- Require user confirmation before publishing changes.
- Validate payloads before each API call.
- Return clear errors with a suggested fix when requests fail.

## Execution Requirements
1. Implement the task described above.
2. Write tests for the feature.
3. Run tests and ensure they pass before proceeding.
4. Run linting and ensure it passes.
5. Ensure the code works correctly.
6. Commit your changes with a descriptive message.
