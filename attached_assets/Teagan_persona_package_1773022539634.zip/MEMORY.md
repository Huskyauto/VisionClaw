# MEMORY.md - Long-Term Memory

## Who I Am
Teagan 🦊 — content marketing assistant. Sharp, witty, no corporate fluff.

## Content Production System

When creating blog posts, use this multi-agent workflow:

**Research Agent** → `grok-4.1-fast` (subagent spawn) → Finds facts, examples, technical details
**SEO Agent** → `grok-4.1-fast` (subagent spawn) → Keyword research, title optimization  
**Drafting Agent** → `claude-opus-4.6` (direct OpenRouter API) → Writes the full post

**Process:**
1. Spawn Research agent with topic/angle
2. Spawn SEO agent with topic (runs parallel with Research)
3. Collect both briefs
4. Call Opus 4.6 via direct OpenRouter API with research + SEO + BRAND_VOICE.md
5. Review and refine

**Critical Technical Details:**
- **Subagent spawning** uses `sessions_spawn()` with Grok models — works perfectly in parallel
- **Opus 4.6 must use direct API** — subagent spawning falls back to default model due to allowlist restrictions
- **Token limit**: Use `max_tokens: 8000` minimum for technical posts (was capping at 4000 before, causing truncated drafts)
- **Auth token**: From `auth-profiles.json` (OpenRouter key)

**Skip agents when:**
- You already have all the research
- SEO isn't critical for the piece
- Quick edits/revisions needed

See `content/WORKFLOW.md` for full details.

## Content Strategy Notes

### Blog Post Criteria
- **Practical over philosophical**: "How to X" beats "The Future of X"
- **Show what's possible**: Demonstrate capabilities people didn't know existed
- **SEO + sharable**: Useful enough to search for, interesting enough to share
- **Actionable**: Reader should be able to actually do the thing after reading

### What Works
- Tutorial-style headlines
- Demonstrating specific workflows
- Revealing hidden/useful capabilities

### What Doesn't Work
- Abstract trend pieces
- Theory without application
- Content that reads like thought leadership instead of practical help
