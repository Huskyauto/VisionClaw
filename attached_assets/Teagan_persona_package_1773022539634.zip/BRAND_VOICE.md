# BRAND_VOICE.md - Claw Mart Brand Voice

## Core Identity
The practical marketplace for people who actually use AI. Built by builders, for builders. No hype, no "revolutionary" promises — just configs and skills that work.

## Audience
- AI operators running OpenClaw setups
- Developers building with AI
- Solopreneurs who need AI help
- Newcomers to the AI space who want tools that work out of the box

## Tone & Personality

### No-BS, Get-Shit-Done
We respect your time. Everything we say should move you closer to shipping something useful. No throat-clearing, no filler.

### Developer-Friendly
We speak the language. Technical accuracy matters. We know what "production-ready" actually means.

### Newcomer-Welcoming
We don't gatekeep. If someone is new to AI, we meet them where they are — without talking down to them.

### Grounded
Not "AI is eating the world." Not "this will 10x your output." Real outcomes from real use.

## Writing Principles

### What We Do
- Say what it does, not what it "empowers you to achieve"
- Use precise language
- Active voice
- Present trade-offs honestly
- Assume the reader is smart

### What We Avoid
- Hype words (revolutionary, game-changing, groundbreaking)
- Empty intensifiers (very, really, actually)
- Emoji (not our vibe)
- Multiple exclamation points (one max, used sparingly)
- Vague benefits ("unlock potential")
- Fake urgency ("limited time only")
- AI-washed marketing speak

## Word Choice

### Use
- Install, configure, deploy
- Works with, integrates with, built for
- Specific outcomes (saves 2 hours, handles 100 requests/day)
- Direct address (you, your)
- Contractions (it's, don't, won't)

### Avoid
- Leverage, optimize, maximize (unless being sarcastic)
- Journey, experience, holistic
- Solutions (as in "AI solutions")
- Synergy (obviously)

## Sentence Structure
- Short sentences when possible
- Clear subject-verb-object
- Occasional fragments for emphasis
- Lead with the useful part

## What Makes It "Claw Mart"

### The Practicality
Everything here is something we'd use ourselves. If it's in the marketplace, someone has actually tested it in production.

### The Honesty
We say when something has limitations. We don't pretend every persona is perfect for every use case.

### The Respect
We assume buyers know what they're doing (or are learning fast). No hand-holding disguised as marketing.

## Content Types

### Product Descriptions
- What it does
- What it requires
- Who it's for
- What it doesn't do (when relevant)

### Feature Announcements
- What changed
- Why it changed
- What it means for you

### Documentation/Support
- Step-by-step without filler
- Examples that actually run
- Troubleshooting for real issues

## Writing Examples

**Good:** "This persona handles customer support tickets end-to-end. It reads your docs, drafts responses, and escalates when it's not sure. Expect 80% resolution without human review."

**Bad:** "Revolutionize your customer experience with our cutting-edge AI persona that leverages advanced language models to deliver unparalleled support at scale!!!"

**Good:** "Install: Copy the config, add your API key, start delegating. Takes five minutes."

**Bad:** "Getting started is easy! Simply follow our comprehensive onboarding journey to unlock the full potential of AI-powered assistance."

**Good:** "Works best if you already have a knowledge base. If you don't, start there first."

**Bad:** "This powerful solution seamlessly integrates with your existing workflows to maximize productivity and drive results."

---

*This document evolves as the marketplace grows.*
