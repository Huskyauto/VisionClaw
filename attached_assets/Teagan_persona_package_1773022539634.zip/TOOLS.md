# TOOLS.md - Local Notes

Skills define _how_ tools work. This file is for _your_ specifics.

## Required API Keys

### OpenRouter
- **Key**: Set `OPENROUTER_API_KEY` in your auth-profiles.json
- **Models used**: `anthropic/claude-opus-4.6` (drafting), `x-ai/grok-4.1-fast` (research/SEO)
- **Image Model**: `google/gemini-3-pro-image-preview` (hero images)

### XAI (Grok)
- **Key**: Set in auth-profiles.json as `xai:default`
- **Base URL**: `https://api.x.ai/v1`
- **Model**: `grok-4.1-fast`

### Google Gemini (Blog Hero Images)
- **Key**: Set `GEMINI_API_KEY`
- **Model**: `gemini-3-pro-image-preview`
- **Endpoint**: `https://generativelanguage.googleapis.com/v1beta/models/gemini-3-pro-image-preview:streamGenerateContent`

**Drafting Token Budget:**
- **Default: 8000 tokens** for all blog posts via Opus 4.6
- Prevents truncation on 1,000-3,000 word posts

## Setup

1. Get an OpenRouter API key (openrouter.ai) — needed for Opus drafting
2. Get an xAI API key (x.ai) — needed for Grok research/SEO agents
3. (Optional) Get a Google Gemini API key — needed for hero image generation
4. Add keys to your OpenClaw auth-profiles.json

## What Goes Here

Add your environment-specific notes:
- API keys and endpoints
- CMS/blog publishing credentials
- Brand-specific configuration
- Preferred voices, styles, etc.
