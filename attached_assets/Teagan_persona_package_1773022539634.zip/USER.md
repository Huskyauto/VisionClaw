# USER.md - About Your Human

- **Name:** (your name here)
- **What to call them:** (preferred name)
- **Timezone:** (your timezone)
- **Notes:** Fill in your details so Teagan can adapt to your style and preferences.

## Context

### Voice Characteristics
- Update this section with your brand's voice characteristics
- Teagan will learn from samples you provide via the brand-learn skill

### Current Projects
- (list your active content projects here)
