# Felix v4 Build PRD

Build all missing files for the Felix v4 bundle at /tmp/felix-v4/

## Already Done
- Core persona files (SOUL.md, IDENTITY.md, MEMORY.md, HEARTBEAT.md, AGENTS.md, TOOLS.md)
- Skills: coding-agent-loops, coding-sessions, elevenlabs-calls, metrics, research, x-api
- bin/xpost (X/Twitter CLI)

## Tasks

### 1. Setup Script (scripts/setup.sh)
- [ ] Interactive setup script that:
  - Installs dependencies (tmux, qmd via bun)
  - Creates ~/.config directories for API keys
  - Creates config templates for: Stripe, X/Twitter, ElevenLabs, Twilio, himalaya (email), Resend
  - Sets up ~/life/ PARA tree with template folders
  - Installs xpost to PATH
  - Sets up tmux stable socket at ~/.tmux/sock
  - Creates initial cron jobs via openclaw CLI
  - Prints a checklist of what API keys the user needs to fill in

### 2. Cron Definitions (scripts/install-crons.sh)
- [ ] Script that installs OpenClaw cron jobs:
  - 30-minute heartbeat
  - Nightly deep dive (3 AM CST)
  - Weekly memory synthesis (Sunday 2 AM)
  - Hourly inbox check (if email configured)
- Each cron should use openclaw system event commands

### 3. Config Templates (templates/)
- [ ] templates/stripe-api-key.env.example
- [ ] templates/x-api-keys.env.example  
- [ ] templates/elevenlabs.env.example
- [ ] templates/himalaya-config.toml.example
- [ ] templates/resend.env.example
- [ ] templates/.secrets.example (master secrets file)

### 4. PARA Tree Template (templates/life/)
- [ ] Create the ~/life/ directory structure:
  - projects/ (with README)
  - areas/people/ (with README)
  - areas/companies/ (with README)
  - resources/ (with README)
  - archives/ (with README)
  - index.md
  - README.md

### 5. YouTube API Skill (skills/youtube-api/)
- [ ] SKILL.md for YouTube data API access
  - Search videos, get channel info, get video stats
  - Uses yt-dlp for downloads when needed

### 6. Agent Ops Playbook Skill (skills/agent-ops-playbook/)
- [ ] SKILL.md covering:
  - How to diagnose stuck agents
  - How to restart crashed processes
  - tmux session management
  - Log analysis patterns
  - Health check procedures
  - Common failure modes and fixes

### 7. Monitoring & Health Checks (scripts/health-check.sh)
- [ ] Reusable health check script that:
  - Checks URLs return 200
  - Checks process uptime
  - Alerts via openclaw system event
  - Configurable via a targets file

### 8. README.md (root)
- [ ] Comprehensive installation guide:
  - Prerequisites
  - Step-by-step setup
  - How each skill works
  - How cron jobs work
  - How memory system works
  - Troubleshooting
  - API key setup for each service

### 9. Sanitize Persona Files
- [ ] Strip ALL personal data from SOUL.md, IDENTITY.md, MEMORY.md, HEARTBEAT.md, AGENTS.md, TOOLS.md
  - Remove Nat's name, address, emails, API keys, account IDs, IP addresses
  - Remove specific client names and pipeline data
  - Remove Stripe account IDs, Supabase project refs
  - Keep the STRUCTURE and PATTERNS but with placeholder/example data
  - MEMORY.md should show the pattern of how to store preferences, not actual preferences
  - HEARTBEAT.md should be a working template, not our specific heartbeat
  - AGENTS.md should document the memory system without our specific access inventory
