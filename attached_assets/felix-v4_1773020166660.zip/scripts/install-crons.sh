#!/usr/bin/env bash
set -euo pipefail

TZ_NAME="${OPENCLAW_CRON_TZ:-America/Chicago}"
LOG_DIR="${OPENCLAW_LOG_DIR:-$HOME/.openclaw/logs}"
FORCE_INBOX="${FORCE_INBOX_CRON:-0}"

mkdir -p "$LOG_DIR"

if ! command -v crontab >/dev/null 2>&1; then
  echo "ERROR: crontab is required but not found" >&2
  exit 1
fi

if ! command -v openclaw >/dev/null 2>&1; then
  echo "ERROR: openclaw CLI not found in PATH" >&2
  exit 1
fi

TMP_FILE="$(mktemp)"
trap 'rm -f "$TMP_FILE"' EXIT

(crontab -l 2>/dev/null || true) > "$TMP_FILE"

if grep -q '^# OPENCLAW_CRON_BEGIN$' "$TMP_FILE"; then
  awk '
    BEGIN {skip=0}
    /^# OPENCLAW_CRON_BEGIN$/ {skip=1; next}
    /^# OPENCLAW_CRON_END$/ {skip=0; next}
    skip==0 {print}
  ' "$TMP_FILE" > "${TMP_FILE}.clean"
  mv "${TMP_FILE}.clean" "$TMP_FILE"
fi

{
  echo "# OPENCLAW_CRON_BEGIN"
  echo "CRON_TZ=$TZ_NAME"
  echo "*/30 * * * * /bin/zsh -lc 'openclaw system event --mode now --text \"heartbeat: execution + health\"' >> \"$LOG_DIR/heartbeat.log\" 2>&1"
  echo "0 3 * * * /bin/zsh -lc 'openclaw system event --mode now --text \"nightly-deep-dive: review + plan\"' >> \"$LOG_DIR/nightly-deep-dive.log\" 2>&1"
  echo "0 2 * * 0 /bin/zsh -lc 'openclaw system event --mode now --text \"weekly-synthesis: memory + process refinement\"' >> \"$LOG_DIR/weekly-synthesis.log\" 2>&1"

  if [[ "$FORCE_INBOX" == "1" || -s "$HOME/.config/himalaya/config.toml" ]]; then
    echo "0 * * * * /bin/zsh -lc 'openclaw system event --mode now --text \"inbox-check: process inbound queue\"' >> \"$LOG_DIR/inbox-check.log\" 2>&1"
  else
    echo "# inbox-check cron skipped (configure ~/.config/himalaya/config.toml or set FORCE_INBOX_CRON=1)"
  fi

  echo "# OPENCLAW_CRON_END"
} >> "$TMP_FILE"

crontab "$TMP_FILE"

echo "Installed OpenClaw cron jobs with timezone: $TZ_NAME"
echo "Current managed block:"
crontab -l | sed -n '/OPENCLAW_CRON_BEGIN/,/OPENCLAW_CRON_END/p'
