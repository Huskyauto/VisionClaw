#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
AUTO_YES=0
SKIP_CRONS=0

usage() {
  cat <<'USAGE'
Usage: scripts/setup.sh [--yes] [--skip-crons]

Interactive bootstrap for Felix v4/OpenClaw bundle.

Options:
  -y, --yes       Run non-interactively with default yes answers
      --skip-crons  Skip cron installation step
  -h, --help      Show this help
USAGE
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    -y|--yes)
      AUTO_YES=1
      shift
      ;;
    --skip-crons)
      SKIP_CRONS=1
      shift
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      echo "Unknown option: $1" >&2
      usage
      exit 1
      ;;
  esac
done

say() {
  printf '%s\n' "$*"
}

warn() {
  printf 'WARN: %s\n' "$*" >&2
}

prompt_yes_no() {
  local question="$1"
  local default="${2:-Y}"
  local reply

  if [[ "$AUTO_YES" -eq 1 ]]; then
    return 0
  fi

  if [[ "$default" == "Y" ]]; then
    read -r -p "$question [Y/n]: " reply
    [[ -z "$reply" || "$reply" =~ ^[Yy]$ ]]
  else
    read -r -p "$question [y/N]: " reply
    [[ "$reply" =~ ^[Yy]$ ]]
  fi
}

copy_template_if_missing() {
  local src="$1"
  local dst="$2"

  if [[ ! -f "$src" ]]; then
    warn "Template not found: $src"
    return 1
  fi

  mkdir -p "$(dirname "$dst")"

  if [[ -f "$dst" ]]; then
    if prompt_yes_no "File exists: $dst. Overwrite with template?" "N"; then
      cp "$src" "$dst"
      say "Updated: $dst"
    else
      say "Kept existing: $dst"
    fi
  else
    cp "$src" "$dst"
    say "Created: $dst"
  fi
}

install_tmux() {
  if command -v tmux >/dev/null 2>&1; then
    say "tmux already installed"
    return 0
  fi

  warn "tmux not found; attempting install"
  if command -v brew >/dev/null 2>&1; then
    brew install tmux
  elif command -v apt-get >/dev/null 2>&1; then
    sudo apt-get update && sudo apt-get install -y tmux
  elif command -v dnf >/dev/null 2>&1; then
    sudo dnf install -y tmux
  else
    warn "No supported package manager found for tmux install"
    return 1
  fi
}

install_bun() {
  if command -v bun >/dev/null 2>&1; then
    say "bun already installed"
    return 0
  fi

  warn "bun not found; attempting install"
  curl -fsSL https://bun.sh/install | bash
  export PATH="$HOME/.bun/bin:$PATH"
}

install_qmd() {
  if command -v qmd >/dev/null 2>&1; then
    say "qmd already installed"
    return 0
  fi

  if ! command -v bun >/dev/null 2>&1; then
    warn "bun is required to install qmd"
    return 1
  fi

  bun add -g qmd || bun install -g qmd
}

setup_config_templates() {
  mkdir -p \
    "$HOME/.config/stripe" \
    "$HOME/.config/x-api" \
    "$HOME/.config/elevenlabs" \
    "$HOME/.config/twilio" \
    "$HOME/.config/himalaya" \
    "$HOME/.config/resend" \
    "$HOME/.config/openclaw" \
    "$HOME/.clawdbot"

  copy_template_if_missing "$ROOT_DIR/templates/stripe-api-key.env.example" "$HOME/.config/stripe/api_key.env"
  copy_template_if_missing "$ROOT_DIR/templates/x-api-keys.env.example" "$HOME/.config/x-api/keys.env"
  copy_template_if_missing "$ROOT_DIR/templates/elevenlabs.env.example" "$HOME/.config/elevenlabs/api_key.env"
  copy_template_if_missing "$ROOT_DIR/templates/twilio.env.example" "$HOME/.config/twilio/credentials.env"
  copy_template_if_missing "$ROOT_DIR/templates/himalaya-config.toml.example" "$HOME/.config/himalaya/config.toml"
  copy_template_if_missing "$ROOT_DIR/templates/resend.env.example" "$HOME/.config/resend/api_key.env"
  copy_template_if_missing "$ROOT_DIR/templates/.secrets.example" "$HOME/.clawdbot/.secrets"
  copy_template_if_missing "$ROOT_DIR/templates/health-targets.conf.example" "$HOME/.config/openclaw/health-targets.conf"

  chmod 600 "$HOME/.clawdbot/.secrets" 2>/dev/null || true
  chmod 600 "$HOME/.config/himalaya/config.toml" 2>/dev/null || true
}

copy_tree_if_missing() {
  local src="$1"
  local dst="$2"

  mkdir -p "$dst"

  if command -v rsync >/dev/null 2>&1; then
    rsync -a --ignore-existing "$src/" "$dst/"
  else
    cp -R -n "$src/." "$dst/" 2>/dev/null || cp -R "$src/." "$dst/"
  fi
}

setup_para_tree() {
  local life_dir="$HOME/life"
  mkdir -p "$life_dir"
  copy_tree_if_missing "$ROOT_DIR/templates/life" "$life_dir"
  say "PARA tree ready at: $life_dir"
}

install_xpost() {
  local src="$ROOT_DIR/bin/xpost"
  local dst_dir="$HOME/.local/bin"
  local dst="$dst_dir/xpost"

  if [[ ! -f "$src" ]]; then
    warn "xpost not found at $src"
    return 1
  fi

  mkdir -p "$dst_dir"
  cp "$src" "$dst"
  chmod +x "$dst"
  say "Installed xpost to: $dst"

  if [[ ":$PATH:" != *":$dst_dir:"* ]]; then
    if prompt_yes_no "Add $dst_dir to PATH in ~/.zshrc?" "Y"; then
      if ! grep -Fq 'export PATH="$HOME/.local/bin:$PATH"' "$HOME/.zshrc" 2>/dev/null; then
        printf '\nexport PATH="$HOME/.local/bin:$PATH"\n' >> "$HOME/.zshrc"
      fi
      say "Added ~/.local/bin PATH export to ~/.zshrc"
    else
      warn "PATH not updated automatically; add $dst_dir manually if needed"
    fi
  fi
}

setup_tmux_socket() {
  mkdir -p "$HOME/.tmux"
  if command -v tmux >/dev/null 2>&1; then
    tmux -S "$HOME/.tmux/sock" start-server || true
    say "tmux stable socket ready: ~/.tmux/sock"
  else
    warn "tmux unavailable; skipped stable socket initialization"
  fi
}

install_crons() {
  if [[ "$SKIP_CRONS" -eq 1 ]]; then
    say "Skipped cron installation (--skip-crons)"
    return 0
  fi

  local installer="$ROOT_DIR/scripts/install-crons.sh"
  if [[ ! -x "$installer" ]]; then
    warn "Cron installer missing or not executable: $installer"
    return 1
  fi

  "$installer"
}

print_checklist() {
  cat <<'CHECKLIST'

Setup complete. Fill these values before production use:

1. ~/.config/stripe/api_key.env
   - STRIPE_SECRET_KEY
   - STRIPE_ACCOUNT_ID (optional but recommended)

2. ~/.config/x-api/keys.env
   - X_API_KEY
   - X_API_SECRET
   - X_ACCESS_TOKEN
   - X_ACCESS_TOKEN_SECRET
   - X_USER_ID

3. ~/.config/elevenlabs/api_key.env
   - ELEVENLABS_API_KEY

4. ~/.config/twilio/credentials.env
   - TWILIO_ACCOUNT_SID
   - TWILIO_AUTH_TOKEN
   - TWILIO_PHONE_NUMBER

5. ~/.config/himalaya/config.toml
   - email/login/app-password command

6. ~/.config/resend/api_key.env
   - RESEND_API_KEY
   - RESEND_FROM_EMAIL

7. ~/.clawdbot/.secrets
   - OPENCLAW_API_KEY
   - Any service secrets required by your deployment

8. ~/.config/openclaw/health-targets.conf
   - Add URL and process checks for scripts/health-check.sh

Recommended validation:
- `xpost --help`
- `scripts/health-check.sh -t ~/.config/openclaw/health-targets.conf --verbose`
- `crontab -l | sed -n '/OPENCLAW_CRON_BEGIN/,/OPENCLAW_CRON_END/p'`
CHECKLIST
}

main() {
  say "== Felix v4 Setup =="

  if prompt_yes_no "Install/verify dependencies (tmux, bun, qmd)?" "Y"; then
    install_tmux || warn "tmux install step had issues"
    install_bun || warn "bun install step had issues"
    install_qmd || warn "qmd install step had issues"
  fi

  if prompt_yes_no "Create config directories and copy template files?" "Y"; then
    setup_config_templates
  fi

  if prompt_yes_no "Create ~/life PARA tree from templates?" "Y"; then
    setup_para_tree
  fi

  if prompt_yes_no "Install xpost to ~/.local/bin?" "Y"; then
    install_xpost || warn "xpost install step had issues"
  fi

  if prompt_yes_no "Configure tmux stable socket (~/.tmux/sock)?" "Y"; then
    setup_tmux_socket
  fi

  if prompt_yes_no "Install OpenClaw cron jobs now?" "Y"; then
    install_crons || warn "Cron install step had issues"
  fi

  print_checklist
}

main "$@"
