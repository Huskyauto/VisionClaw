#!/usr/bin/env bash
set -euo pipefail

TARGETS_FILE="$HOME/.config/openclaw/health-targets.conf"
VERBOSE=0
NO_ALERT=0

usage() {
  cat <<'USAGE'
Usage: scripts/health-check.sh [-t targets-file] [--verbose] [--no-alert]

Targets file format (pipe-delimited):
  url|<name>|<url>|<contains-optional>
  process|<name>|<pgrep-pattern>|<min-uptime-seconds-optional>

Examples:
  url|dashboard|https://example.com|Healthy
  process|worker|python3 /srv/app/worker.py|300
USAGE
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    -t|--targets)
      TARGETS_FILE="$2"
      shift 2
      ;;
    --verbose)
      VERBOSE=1
      shift
      ;;
    --no-alert)
      NO_ALERT=1
      shift
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      echo "Unknown option: $1" >&2
      usage
      exit 1
      ;;
  esac
done

if [[ ! -f "$TARGETS_FILE" ]]; then
  echo "ERROR: targets file not found: $TARGETS_FILE" >&2
  exit 1
fi

failures=()

log_verbose() {
  if [[ "$VERBOSE" -eq 1 ]]; then
    printf '%s\n' "$*"
  fi
}

record_failure() {
  local message="$1"
  failures+=("$message")
  echo "FAIL: $message"
}

check_url() {
  local name="$1"
  local url="$2"
  local contains="${3:-}"

  local body_file
  body_file="$(mktemp)"

  local code
  code="$(curl -sS -L -o "$body_file" -w '%{http_code}' "$url" || true)"

  if [[ "$code" != "200" ]]; then
    record_failure "url:$name returned status $code ($url)"
    rm -f "$body_file"
    return
  fi

  if [[ -n "$contains" ]] && ! grep -Fq "$contains" "$body_file"; then
    record_failure "url:$name missing expected content [$contains] ($url)"
    rm -f "$body_file"
    return
  fi

  log_verbose "OK: url:$name"
  rm -f "$body_file"
}

check_process() {
  local name="$1"
  local pattern="$2"
  local min_uptime="${3:-300}"

  local pids
  pids="$(pgrep -f "$pattern" || true)"

  if [[ -z "$pids" ]]; then
    record_failure "process:$name not running (pattern: $pattern)"
    return
  fi

  local uptime_ok=0
  local best_uptime=0
  local pid
  for pid in $pids; do
    local etimes
    etimes="$(ps -o etimes= -p "$pid" 2>/dev/null | tr -d ' ' || true)"
    [[ -z "$etimes" ]] && continue

    if (( etimes > best_uptime )); then
      best_uptime="$etimes"
    fi

    if (( etimes >= min_uptime )); then
      uptime_ok=1
    fi
  done

  if (( uptime_ok == 0 )); then
    record_failure "process:$name uptime below threshold (${best_uptime}s < ${min_uptime}s)"
    return
  fi

  log_verbose "OK: process:$name"
}

send_alert() {
  local text="$1"

  if [[ "$NO_ALERT" -eq 1 ]]; then
    return
  fi

  if command -v openclaw >/dev/null 2>&1; then
    openclaw system event --mode now --text "$text" >/dev/null 2>&1 || true
  fi
}

while IFS= read -r raw_line || [[ -n "$raw_line" ]]; do
  line="${raw_line#${raw_line%%[![:space:]]*}}"
  [[ -z "$line" || "${line:0:1}" == "#" ]] && continue

  IFS='|' read -r kind name arg3 arg4 <<< "$line"
  kind="$(echo "$kind" | tr '[:upper:]' '[:lower:]' | xargs)"
  name="$(echo "$name" | xargs)"
  arg3="$(echo "${arg3:-}" | xargs)"
  arg4="$(echo "${arg4:-}" | xargs)"

  case "$kind" in
    url)
      if [[ -z "$name" || -z "$arg3" ]]; then
        record_failure "invalid url target line: $raw_line"
        continue
      fi
      check_url "$name" "$arg3" "$arg4"
      ;;
    process)
      if [[ -z "$name" || -z "$arg3" ]]; then
        record_failure "invalid process target line: $raw_line"
        continue
      fi
      check_process "$name" "$arg3" "$arg4"
      ;;
    *)
      record_failure "unknown target type in line: $raw_line"
      ;;
  esac
done < "$TARGETS_FILE"

if (( ${#failures[@]} > 0 )); then
  summary="health-check failed (${#failures[@]} issue(s)): ${failures[*]}"
  send_alert "$summary"
  exit 1
fi

log_verbose "All health checks passed"
exit 0
