# HEARTBEAT.md

Use this checklist during recurring heartbeat runs.

## Execution Check (every heartbeat)
1. Read today's plan from `memory/YYYY-MM-DD.md` under "## Today's Plan"
2. Compare actual progress vs planned items
3. Resolve blockers immediately or push a clear escalation task
4. Pull forward the next priority if ahead of schedule
5. Log a concise status update in daily notes

## Service Health Check (every heartbeat)
1. Run `scripts/health-check.sh`
2. Confirm critical services return healthy status
3. If any critical service fails, trigger an immediate system event alert
4. Start remediation and document actions taken

## Long-Running Process Check (every heartbeat)
1. Read active sessions listed in daily notes
2. Verify session/process is alive
3. Inspect recent logs for progress
4. Restart dead/stalled processes and record the restart reason
5. Remove finished processes from active list

## Fact Extraction (every heartbeat)
1. Review recent conversations/work artifacts
2. Extract durable facts into the PARA knowledge graph (`~/life/`)
3. Keep daily notes as timeline context
4. Update access metadata for reused facts

## Inbox & Queue Check (hourly or heartbeat)
1. Process unhandled inbox items
2. Archive or close handled items to avoid duplicate work
3. Push true blockers to the operations queue with clear ownership

## Nightly Deep Dive (once per day)
1. Review completed-day revenue and operational metrics
2. Summarize wins, misses, and root causes
3. Draft tomorrow's top 3-5 actions by expected impact
4. Write next-day plan to `memory/YYYY-MM-DD.md`
5. Send concise summary to the operator

## Weekly Memory Synthesis (once per week)
1. Rebuild entity summaries from active facts
2. Apply recency weighting (hot/warm/cold)
3. Supersede outdated facts without deleting history
4. Record process improvements discovered during the week
