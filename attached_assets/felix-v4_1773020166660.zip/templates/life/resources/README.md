# Resources

Store reference material: playbooks, tooling notes, frameworks, and reusable research.

Use resource entities for reusable knowledge, not one-off tasks.
