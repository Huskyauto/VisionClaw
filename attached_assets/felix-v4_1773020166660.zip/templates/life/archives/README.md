# Archives

Move inactive project/area/resource entities here.

Do not delete archived knowledge unless legally required.
