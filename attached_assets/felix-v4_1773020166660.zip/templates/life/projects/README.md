# Projects

Use this folder for active projects with clear outcomes and deadlines.

## Suggested Entity Structure
- `summary.md` for compact context
- `items.json` for atomic facts
- Optional `notes.md` for working detail

Archive completed projects by moving them into `../archives/`.
