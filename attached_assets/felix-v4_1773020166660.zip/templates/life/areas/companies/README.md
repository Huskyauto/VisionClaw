# Areas / Companies

Store ongoing context for companies, clients, vendors, and partners.

## Suggested Entity Structure
- `summary.md`
- `items.json`

Track status, constraints, priorities, and key milestones.
