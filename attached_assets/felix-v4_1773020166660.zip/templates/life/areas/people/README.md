# Areas / People

Store durable relationship context for people the operator works with regularly.

## Suggested Entity Structure
- `summary.md`
- `items.json`

Include only durable facts and preferences that improve future execution.
