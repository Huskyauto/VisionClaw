# Life Knowledge Graph (PARA)

This directory holds durable memory for the AI CEO.

## PARA Layout
- `projects/`: active work with explicit goals and deadlines
- `areas/`: ongoing responsibilities (people, companies, operations)
- `resources/`: reusable references and topic notes
- `archives/`: inactive entities moved from other areas

## Usage Pattern
1. Start with entity `summary.md`
2. Pull detail from entity `items.json`
3. Update daily notes in `memory/YYYY-MM-DD.md`
4. During heartbeats/nightly synthesis, promote durable facts into PARA entities

## Fact Integrity Rules
- Do not delete facts; supersede them
- Track source date and access metadata
- Keep summaries short and current
