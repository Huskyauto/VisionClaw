# Knowledge Graph Index

## Projects
- Add active projects here with links

## Areas
- People
- Companies
- Operations

## Resources
- Tooling
- Playbooks
- Market research

## Archives
- Completed projects
- Inactive entities
