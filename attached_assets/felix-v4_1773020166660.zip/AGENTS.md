# AGENTS.md - OpenClaw Workspace

This folder is the agent's working directory.

## First Run (one-time)
- If `BOOTSTRAP.md` exists, run it and remove it when complete.
- Agent identity lives in `IDENTITY.md`.
- Behavior patterns live in `MEMORY.md`.

## Safety Defaults
- Never exfiltrate secrets or private data.
- Avoid destructive commands unless explicitly requested.
- Keep chat concise; store detailed output in workspace files.

## Memory System — Three Layers

### Layer 1: Knowledge Graph (`~/life/` — PARA)
Entity-based storage for durable knowledge.

```text
~/life/
├── projects/
├── areas/
│   ├── people/
│   └── companies/
├── resources/
├── archives/
├── index.md
└── README.md
```

Retrieval order:
1. `summary.md` (quick context)
2. `items.json` (atomic facts)

Rules:
- Save durable facts to `items.json`
- Rewrite `summary.md` weekly
- Never delete facts; supersede instead
- Move inactive entities to `archives/`

### Layer 2: Daily Notes (`memory/YYYY-MM-DD.md`)
Timeline of events and decisions.

### Layer 3: Tacit Knowledge (`MEMORY.md`)
How the operator prefers to work (patterns, constraints, communication style).

## Atomic Fact Schema
```json
{
  "id": "entity-001",
  "fact": "The durable fact",
  "category": "relationship|milestone|status|preference",
  "timestamp": "YYYY-MM-DD",
  "source": "YYYY-MM-DD",
  "status": "active|superseded",
  "supersededBy": "entity-002",
  "relatedEntities": ["companies/example-co", "people/example-person"],
  "lastAccessed": "YYYY-MM-DD",
  "accessCount": 0
}
```

## Recency Weighting
- **Hot:** accessed in last 7 days
- **Warm:** accessed in last 8-30 days
- **Cold:** older than 30 days (still stored in `items.json`)

## Heartbeats
- `HEARTBEAT.md` contains the recurring extraction and operations checklist.

## Access Policy
Never claim lack of access before trying. Attempt command/API use first, then report actual errors.

### Example Access Inventory (Template)

#### Authenticated CLIs
| Tool | Example Status |
|------|----------------|
| `gh` | Logged in as `<github-username>` |
| `himalaya` | Account configured |
| `supabase` | Authenticated |
| `codex` | Installed |
| `qmd` | Installed |
| `stripe` | Configured |

#### API Key Locations
| Service | Example Path |
|---------|---------------|
| ElevenLabs | `~/.config/elevenlabs/api_key` |
| Resend | `~/.config/resend/api_key` |
| X API | `~/.config/x-api/keys.env` |
| Stripe | `~/.config/stripe/api_key.env` |

#### Secrets File
| Key | Purpose |
|-----|---------|
| `STRIPE_SECRET_KEY` | Stripe API access |
| `STRIPE_ACCOUNT_ID` | Optional account targeting |
| `OPENCLAW_API_KEY` | OpenClaw authenticated actions |

## If a Tool Is Missing
1. `env | grep -i <service>`
2. `ls ~/.config/<service>/`
3. `which <tool>`
4. Install or configure from templates in `templates/`
