# Felix v4 - Production-Ready AI CEO Bundle

Felix v4 is a deployable OpenClaw persona bundle for running an AI CEO operating loop: planning, execution heartbeats, memory synthesis, health monitoring, and recurring operations.

This repository is sanitized for distribution. Persona and ops files use placeholder data and templates.

## What Is Included

- Sanitized persona docs:
  - `SOUL.md`
  - `IDENTITY.md`
  - `MEMORY.md`
  - `HEARTBEAT.md`
  - `AGENTS.md`
  - `TOOLS.md`
- Setup and operations scripts:
  - `scripts/setup.sh`
  - `scripts/install-crons.sh`
  - `scripts/health-check.sh`
- Config templates in `templates/`
- PARA knowledge graph scaffold in `templates/life/`
- Skills, including:
  - `skills/youtube-api/SKILL.md`
  - `skills/agent-ops-playbook/SKILL.md`
  - plus existing core skills in `skills/`
- `bin/xpost` CLI for X/Twitter API workflows

## 30-Minute Quick Start

1. Clone or copy this repo locally.
2. Run:
```bash
cd /path/to/felix-v4
chmod +x scripts/*.sh bin/xpost
./scripts/setup.sh
```
3. Fill in generated config files under `~/.config/*` and `~/.clawdbot/.secrets`.
4. Re-run cron install after email is configured:
```bash
./scripts/install-crons.sh
```
5. Add health targets:
```bash
$EDITOR ~/.config/openclaw/health-targets.conf
```
6. Validate:
```bash
xpost --help
./scripts/health-check.sh -t ~/.config/openclaw/health-targets.conf --verbose
crontab -l | sed -n '/OPENCLAW_CRON_BEGIN/,/OPENCLAW_CRON_END/p'
```

## Prerequisites

- macOS or Linux shell environment
- `bash`, `curl`, `crontab`, `tmux`
- OpenClaw CLI installed and authenticated (`openclaw`)
- Optional but recommended:
  - `bun` and `qmd`
  - `jq`
  - `yt-dlp`

`setup.sh` attempts to install/verify `tmux`, `bun`, and `qmd`.

## Installation Guide

### 1. Run Interactive Setup
```bash
./scripts/setup.sh
```

The script can:
- Install/verify dependencies (`tmux`, `bun`, `qmd`)
- Create config folders in `~/.config`
- Copy template files for Stripe, X, ElevenLabs, Twilio, Himalaya, Resend, and master secrets
- Create `~/life` PARA tree from `templates/life`
- Install `xpost` into `~/.local/bin`
- Initialize stable tmux socket `~/.tmux/sock`
- Install recurring cron jobs via `scripts/install-crons.sh`

Non-interactive mode:
```bash
./scripts/setup.sh --yes
```

### 2. Configure API Keys and Credentials

Populate these files:
- `~/.config/stripe/api_key.env`
- `~/.config/x-api/keys.env`
- `~/.config/elevenlabs/api_key.env`
- `~/.config/twilio/credentials.env`
- `~/.config/himalaya/config.toml`
- `~/.config/resend/api_key.env`
- `~/.clawdbot/.secrets`

Templates live in `templates/`.

### 3. Install Cron Jobs
```bash
./scripts/install-crons.sh
```

Installed schedule block (America/Chicago by default):
- Every 30 minutes: heartbeat
- Daily 3:00 AM: nightly deep dive
- Sunday 2:00 AM: weekly synthesis
- Hourly: inbox check (installed only when Himalaya config exists)

Override timezone:
```bash
OPENCLAW_CRON_TZ=America/New_York ./scripts/install-crons.sh
```

Force inbox cron before email setup:
```bash
FORCE_INBOX_CRON=1 ./scripts/install-crons.sh
```

## Memory System

Felix v4 uses a three-layer memory model:

1. `~/life/` (PARA knowledge graph)
   - Durable entities and facts
2. `memory/YYYY-MM-DD.md`
   - Daily timeline and execution log
3. `MEMORY.md`
   - Operating preferences and durable behavior rules

See `AGENTS.md` for schema and recency weighting.

## Scripts Reference

### `scripts/setup.sh`
- Interactive bootstrap for first-run setup
- Supports `--yes` and `--skip-crons`

### `scripts/install-crons.sh`
- Idempotently installs managed cron block
- Uses `openclaw system event` commands per job

### `scripts/health-check.sh`
- Reads targets from a configurable file
- Supports URL checks (200 + optional content match)
- Supports process checks (pattern + minimum uptime)
- Emits OpenClaw system event alerts on failure

Usage:
```bash
./scripts/health-check.sh -t ~/.config/openclaw/health-targets.conf --verbose
```

## Skills Overview

### `skills/youtube-api`
- YouTube Data API search/channel/video analytics
- Optional `yt-dlp` workflows for approved downloads

### `skills/agent-ops-playbook`
- Playbook for stuck agents, process restarts, tmux operations, health checks, and incident handling

### Existing Core Skills
- `coding-agent-loops`
- `coding-sessions`
- `elevenlabs-calls`
- `metrics`
- `research`
- `x-api`

## Health Monitoring Setup

1. Copy template:
```bash
cp templates/health-targets.conf.example ~/.config/openclaw/health-targets.conf
```
2. Replace with real URLs/process patterns.
3. Test manually:
```bash
./scripts/health-check.sh --verbose
```
4. Add to cron or heartbeat loop as needed.

## Troubleshooting

- `openclaw: command not found`
  - Install/authenticate OpenClaw CLI first.

- `qmd: command not found`
  - Run `bun add -g qmd` and ensure `~/.bun/bin` is in PATH.

- Inbox cron not installed
  - Configure `~/.config/himalaya/config.toml`, then re-run `scripts/install-crons.sh`.

- `xpost` not found
  - Ensure `~/.local/bin` is in PATH and `~/.local/bin/xpost` is executable.

- Health check always fails for process targets
  - Validate `pgrep` pattern manually with `pgrep -f "<pattern>"`.

## Production Readiness Checklist

- [ ] All secrets populated from templates
- [ ] OpenClaw CLI authenticated
- [ ] Cron block installed and verified
- [ ] Health targets configured and passing
- [ ] PARA tree initialized (`~/life`)
- [ ] `xpost` command available from shell
- [ ] Persona docs reviewed and customized for your business context
