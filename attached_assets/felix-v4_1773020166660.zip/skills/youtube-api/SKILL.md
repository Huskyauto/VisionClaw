---
name: youtube-api
description: Access YouTube Data API for search, channel insights, and video stats; use yt-dlp for approved downloads.
---

# YouTube API Skill

Use this skill when you need YouTube discovery, analytics lookups, or media retrieval.

## Prerequisites
- API key stored at `~/.config/youtube/api_key` or exported as `YOUTUBE_API_KEY`
- Optional tools:
  - `jq` for JSON parsing
  - `yt-dlp` for media downloads

## Setup
```bash
mkdir -p ~/.config/youtube
printf '%s\n' 'YOUR_YOUTUBE_API_KEY' > ~/.config/youtube/api_key
chmod 600 ~/.config/youtube/api_key
```

## Helper
```bash
YT_KEY="${YOUTUBE_API_KEY:-$(cat ~/.config/youtube/api_key)}"
BASE="https://www.googleapis.com/youtube/v3"
```

## Search Videos
```bash
curl -s "$BASE/search?part=snippet&type=video&maxResults=10&q=autonomous+agents&key=$YT_KEY" | jq
```

## Channel Info
```bash
curl -s "$BASE/channels?part=snippet,statistics&id=<CHANNEL_ID>&key=$YT_KEY" | jq
```

## Video Stats
```bash
curl -s "$BASE/videos?part=snippet,statistics,contentDetails&id=<VIDEO_ID>&key=$YT_KEY" | jq
```

## Batch Video Lookup
```bash
IDS="id1,id2,id3"
curl -s "$BASE/videos?part=snippet,statistics&id=$IDS&key=$YT_KEY" | jq '.items[] | {id, title: .snippet.title, views: .statistics.viewCount}'
```

## Download with yt-dlp
Use downloads only when policy and rights allow.

```bash
# Metadata only
yt-dlp --skip-download --print "%(_type)s | %(id)s | %(title)s" "https://www.youtube.com/watch?v=<VIDEO_ID>"

# Audio extract
yt-dlp -x --audio-format mp3 -o "%(uploader)s-%(title)s.%(ext)s" "https://www.youtube.com/watch?v=<VIDEO_ID>"

# Video download
yt-dlp -f "bv*+ba/b" -o "%(upload_date)s-%(title)s.%(ext)s" "https://www.youtube.com/watch?v=<VIDEO_ID>"
```

## Operational Rules
- Respect API quotas and retry with backoff on 429/5xx.
- Cache IDs and metadata when iterating on analysis.
- Never hard-code API keys in scripts or commits.
- Verify licensing/usage rights before distributing downloaded media.
