---
name: agent-ops-playbook
description: Diagnose stuck agents, restart failed processes, manage tmux sessions, run health checks, and resolve common operational failures.
---

# Agent Ops Playbook

Use this playbook whenever automation appears stalled, degraded, or broken.

## 1) Diagnose Stuck Agents

### Fast Triage
```bash
ps aux | rg "openclaw|codex|worker|scheduler"
tmux -S ~/.tmux/sock list-sessions
```

### Check Progress vs Stall
```bash
tmux -S ~/.tmux/sock capture-pane -t <session> -p | tail -40
```

Stall indicators:
- Same log output across multiple checks
- No CPU usage and no new log lines
- Repeating recoverable error with no backoff

## 2) Restart Crashed Processes

### Single Process Restart
```bash
pkill -f "<pattern>" || true
nohup <command> >> ~/logs/<name>.log 2>&1 &
```

### tmux Session Restart
```bash
tmux -S ~/.tmux/sock kill-session -t <session> || true
tmux -S ~/.tmux/sock new -d -s <session> "cd <repo> && <command>; echo EXIT:$?; sleep 999999"
```

## 3) tmux Management Standards
- Always use stable socket: `~/.tmux/sock`
- Use named sessions per workload (`inbox`, `builder`, `research`, `cron-runner`)
- Keep completion tail (`echo EXIT:$?; sleep 999999`) for postmortem visibility

Commands:
```bash
tmux -S ~/.tmux/sock list-sessions
tmux -S ~/.tmux/sock attach -t <session>
tmux -S ~/.tmux/sock capture-pane -t <session> -p | tail -80
tmux -S ~/.tmux/sock kill-session -t <session>
```

## 4) Health Check Procedure

### Standard Run
```bash
scripts/health-check.sh -t ~/.config/openclaw/health-targets.conf --verbose
```

### If Failing
1. Identify first failing dependency (URL/process)
2. Restart only the failing component
3. Re-run health check
4. Emit system event with root cause and fix status

## 5) Log Analysis Patterns

Look for:
- Authentication failures (`401`, `403`, token expired)
- Network failures (DNS, timeout, TLS)
- Rate limiting (`429`)
- Resource exhaustion (OOM, file descriptor limits, disk full)

Useful commands:
```bash
tail -n 200 ~/logs/<service>.log
rg -n "ERROR|WARN|429|timeout|ECONN|auth" ~/logs/<service>.log
```

## 6) Common Failure Modes and Fixes

- Missing credentials:
  - Symptom: auth errors at startup
  - Fix: populate template files under `~/.config` and restart

- Cron not firing:
  - Symptom: no periodic events
  - Fix: run `scripts/install-crons.sh`; verify with `crontab -l`

- Zombie/stale worker:
  - Symptom: process exists, no forward progress
  - Fix: restart worker and confirm uptime threshold in health checks

- API quota exhaustion:
  - Symptom: repeated 429 responses
  - Fix: add backoff, reduce polling cadence, spread scheduled jobs

## 7) Escalation Criteria
Escalate immediately when:
- Customer-facing production is down and cannot be restored quickly
- Data integrity is at risk
- Security incident is suspected
- Repeated crash loop persists after one restart cycle

Escalation message format:
- Impact
- Root cause (or best current hypothesis)
- Actions taken
- Next action + ETA
