#!/usr/bin/env python3
"""Pull Google Analytics 4 + Search Console metrics for ClawMart daily reports."""

import argparse
import json
import sys
from datetime import datetime, timedelta

from google.oauth2.service_account import Credentials
from googleapiclient.discovery import build

SA_KEY = "/Users/nat/.config/google/service-account.json"
GA4_PROPERTY = "properties/524863376"
GSC_SITE = "sc-domain:shopclawmart.com"


def get_ga4_metrics(date_str, compare_str):
    """Pull GA4 metrics for a given date and comparison date."""
    creds = Credentials.from_service_account_file(
        SA_KEY, scopes=["https://www.googleapis.com/auth/analytics.readonly"]
    )
    svc = build("analyticsdata", "v1beta", credentials=creds)

    def run_report(start, end):
        body = {
            "dateRanges": [{"startDate": start, "endDate": end}],
            "metrics": [
                {"name": "sessions"},
                {"name": "totalUsers"},
                {"name": "newUsers"},
                {"name": "screenPageViews"},
                {"name": "averageSessionDuration"},
                {"name": "bounceRate"},
                {"name": "conversions"},
            ],
        }
        resp = svc.properties().runReport(property=GA4_PROPERTY, body=body).execute()
        rows = resp.get("rows", [])
        if not rows:
            return {"sessions": 0, "users": 0, "new_users": 0, "pageviews": 0, "avg_session_sec": 0, "bounce_rate": 0, "conversions": 0}
        values = [v.get("value", "0") for v in rows[0].get("metricValues", [])]
        return {
            "sessions": int(values[0]) if len(values) > 0 else 0,
            "users": int(values[1]) if len(values) > 1 else 0,
            "new_users": int(values[2]) if len(values) > 2 else 0,
            "pageviews": int(values[3]) if len(values) > 3 else 0,
            "avg_session_sec": round(float(values[4]), 1) if len(values) > 4 else 0,
            "bounce_rate": round(float(values[5]) * 100, 1) if len(values) > 5 else 0,
            "conversions": int(values[6]) if len(values) > 6 else 0,
        }

    current = run_report(date_str, date_str)
    previous = run_report(compare_str, compare_str)

    # Top pages
    pages_body = {
        "dateRanges": [{"startDate": date_str, "endDate": date_str}],
        "dimensions": [{"name": "pagePath"}],
        "metrics": [{"name": "screenPageViews"}, {"name": "sessions"}],
        "orderBys": [{"metric": {"metricName": "screenPageViews"}, "desc": True}],
        "limit": 10,
    }
    pages_resp = svc.properties().runReport(property=GA4_PROPERTY, body=pages_body).execute()
    top_pages = []
    for row in pages_resp.get("rows", []):
        path = row["dimensionValues"][0]["value"]
        views = int(row["metricValues"][0]["value"])
        sessions = int(row["metricValues"][1]["value"])
        top_pages.append({"path": path, "views": views, "sessions": sessions})

    # Top referrers
    ref_body = {
        "dateRanges": [{"startDate": date_str, "endDate": date_str}],
        "dimensions": [{"name": "sessionSource"}],
        "metrics": [{"name": "sessions"}],
        "orderBys": [{"metric": {"metricName": "sessions"}, "desc": True}],
        "limit": 5,
    }
    ref_resp = svc.properties().runReport(property=GA4_PROPERTY, body=ref_body).execute()
    top_referrers = []
    for row in ref_resp.get("rows", []):
        source = row["dimensionValues"][0]["value"]
        sess = int(row["metricValues"][0]["value"])
        top_referrers.append({"source": source, "sessions": sess})

    return {"current": current, "previous": previous, "top_pages": top_pages, "top_referrers": top_referrers}


def get_gsc_metrics(date_str, compare_str):
    """Pull Search Console metrics."""
    creds = Credentials.from_service_account_file(
        SA_KEY, scopes=["https://www.googleapis.com/auth/webmasters.readonly"]
    )
    svc = build("searchconsole", "v1", credentials=creds)

    def run_query(start, end):
        body = {"startDate": start, "endDate": end, "dimensions": [], "rowLimit": 1}
        try:
            resp = svc.searchanalytics().query(siteUrl=GSC_SITE, body=body).execute()
            rows = resp.get("rows", [])
            if rows:
                r = rows[0]
                return {
                    "clicks": int(r.get("clicks", 0)),
                    "impressions": int(r.get("impressions", 0)),
                    "ctr": round(r.get("ctr", 0) * 100, 2),
                    "position": round(r.get("position", 0), 1),
                }
        except Exception:
            pass
        return {"clicks": 0, "impressions": 0, "ctr": 0, "position": 0}

    current = run_query(date_str, date_str)
    previous = run_query(compare_str, compare_str)

    # Top queries
    q_body = {
        "startDate": date_str,
        "endDate": date_str,
        "dimensions": ["query"],
        "rowLimit": 10,
        "orderBys": [{"fieldName": "clicks", "sortOrder": "DESCENDING"}],  # GSC v3 style
    }
    try:
        q_resp = svc.searchanalytics().query(siteUrl=GSC_SITE, body=q_body).execute()
        top_queries = []
        for row in q_resp.get("rows", []):
            top_queries.append({
                "query": row["keys"][0],
                "clicks": int(row.get("clicks", 0)),
                "impressions": int(row.get("impressions", 0)),
                "ctr": round(row.get("ctr", 0) * 100, 2),
                "position": round(row.get("position", 0), 1),
            })
    except Exception:
        top_queries = []

    return {"current": current, "previous": previous, "top_queries": top_queries}


def delta_str(current, previous):
    if previous == 0:
        return "—" if current == 0 else "+∞"
    pct = ((current - previous) / previous) * 100
    sign = "+" if pct >= 0 else ""
    return f"{sign}{pct:.0f}%"


def format_report(ga4, gsc, date_str, gsc_date_str=None):
    """Format into markdown for Polylogue."""
    c = ga4["current"]
    p = ga4["previous"]
    sc = gsc["current"]
    sp = gsc["previous"]

    lines = [f"### Site Analytics ({date_str})", ""]

    # GA4 summary
    lines.append("**Traffic**")
    lines.append(f"- Sessions: **{c['sessions']:,}** ({delta_str(c['sessions'], p['sessions'])} vs prev day)")
    lines.append(f"- Users: **{c['users']:,}** ({delta_str(c['users'], p['users'])})")
    lines.append(f"- New Users: **{c['new_users']:,}**")
    lines.append(f"- Pageviews: **{c['pageviews']:,}** ({delta_str(c['pageviews'], p['pageviews'])})")
    avg_min = c['avg_session_sec'] / 60
    lines.append(f"- Avg Session: **{avg_min:.1f}min**")
    lines.append(f"- Bounce Rate: **{c['bounce_rate']:.0f}%**")
    if c['conversions']:
        lines.append(f"- Conversions: **{c['conversions']}**")
    lines.append("")

    # Search Console
    gsc_label = f" ({gsc_date_str})" if gsc_date_str and gsc_date_str != date_str else ""
    lines.append(f"**Search Console{gsc_label}**")
    lines.append(f"- Clicks: **{sc['clicks']:,}** ({delta_str(sc['clicks'], sp['clicks'])})")
    lines.append(f"- Impressions: **{sc['impressions']:,}** ({delta_str(sc['impressions'], sp['impressions'])})")
    lines.append(f"- CTR: **{sc['ctr']}%**")
    lines.append(f"- Avg Position: **{sc['position']}**")
    lines.append("")

    # Top pages
    if ga4["top_pages"]:
        lines.append("**Top Pages**")
        for pg in ga4["top_pages"][:7]:
            lines.append(f"- `{pg['path']}` — {pg['views']} views")
        lines.append("")

    # Top referrers
    if ga4["top_referrers"]:
        lines.append("**Top Referrers**")
        for ref in ga4["top_referrers"]:
            lines.append(f"- {ref['source']} — {ref['sessions']} sessions")
        lines.append("")

    # Top search queries
    if gsc["top_queries"]:
        lines.append("**Top Search Queries**")
        for q in gsc["top_queries"][:7]:
            lines.append(f"- \"{q['query']}\" — {q['clicks']} clicks, pos {q['position']}")
        lines.append("")

    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--date", default=None, help="Date to report on (YYYY-MM-DD). Default: yesterday")
    parser.add_argument("--json", action="store_true", help="Output raw JSON instead of markdown")
    args = parser.parse_args()

    if args.date:
        target = datetime.strptime(args.date, "%Y-%m-%d").date()
    else:
        target = datetime.now().date() - timedelta(days=1)

    date_str = target.isoformat()
    compare_str = (target - timedelta(days=1)).isoformat()

    ga4 = get_ga4_metrics(date_str, compare_str)

    # GSC data has a 2-3 day lag; query 3 days ago for reliable data
    gsc_target = datetime.now().date() - timedelta(days=3)
    gsc_date_str = gsc_target.isoformat()
    gsc_compare_str = (gsc_target - timedelta(days=1)).isoformat()
    gsc = get_gsc_metrics(gsc_date_str, gsc_compare_str)

    if args.json:
        print(json.dumps({"ga4": ga4, "gsc": gsc, "gsc_date": gsc_date_str}, indent=2))
    else:
        print(format_report(ga4, gsc, date_str, gsc_date_str=gsc_date_str))


if __name__ == "__main__":
    main()
