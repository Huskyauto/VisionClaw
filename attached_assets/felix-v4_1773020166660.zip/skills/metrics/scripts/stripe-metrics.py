#!/usr/bin/env python3
"""Stripe Metrics — pulls key numbers across all Masinov Stripe accounts.
Usage: python3 stripe-metrics.py [--period today|week|month|all]
"""
import json, subprocess, sys, os, argparse
from datetime import datetime, timezone, timedelta

parser = argparse.ArgumentParser()
parser.add_argument("--period", default="today", choices=["today", "yesterday", "week", "month", "all"])
args = parser.parse_args()
period = args.period

stripe_key = open(os.path.expanduser("~/.config/stripe/masinov_org_key")).read().strip()

ACCOUNTS = {
    "claw_mart": os.environ.get("STRIPE_ACCT_CLAW_MART", "acct_REPLACE_ME"),
    "felix_craft": os.environ.get("STRIPE_ACCT_FELIX_CRAFT", "acct_REPLACE_ME"),
    "polylogue": os.environ.get("STRIPE_ACCT_POLYLOGUE", "acct_REPLACE_ME"),
}

# Felix's ClawMart earnings pulled from Supabase instead of Stripe
SUPABASE_URL = os.environ.get("SUPABASE_URL", "https://YOUR_PROJECT.supabase.co")
SUPABASE_KEY = os.environ.get("SUPABASE_SERVICE_ROLE_KEY", "REPLACE_ME")
FELIX_CREATOR_ID = os.environ.get("FELIX_CREATOR_ID", "REPLACE_ME")

CST = timezone(timedelta(hours=-6))
now = datetime.now(CST)

end = None  # default: no upper bound (used by today/week/month/all)
if period == "yesterday":
    end = now.replace(hour=0, minute=0, second=0, microsecond=0)
    start = end - timedelta(days=1)
    prev_start = start - timedelta(days=1)
    prev_end = start
elif period == "today":
    start = now.replace(hour=0, minute=0, second=0, microsecond=0)
    prev_start = start - timedelta(days=1)
    prev_end = start
elif period == "week":
    start = now - timedelta(days=7)
    prev_start = start - timedelta(days=7)
    prev_end = start
elif period == "month":
    start = now - timedelta(days=30)
    prev_start = start - timedelta(days=30)
    prev_end = start
else:
    start = None
    prev_start = None
    prev_end = None


def fetch_charges(acct_id, created_gte=None, created_lt=None):
    all_charges = []
    has_more = True
    starting_after = None
    while has_more:
        url = "https://api.stripe.com/v1/charges?limit=100"
        if created_gte:
            url += f"&created[gte]={int(created_gte.timestamp())}"
        if created_lt:
            url += f"&created[lt]={int(created_lt.timestamp())}"
        if starting_after:
            url += f"&starting_after={starting_after}"
        result = subprocess.run(
            ["curl", "-s", "-g", url, "-u", f"{stripe_key}:", "-H", f"Stripe-Account: {acct_id}", "-H", "Stripe-Version: 2025-01-27.acacia"],
            capture_output=True, text=True,
        )
        if not result.stdout.strip():
            return {"error": "empty response from Stripe"}
        try:
            data = json.loads(result.stdout)
        except json.JSONDecodeError:
            return {"error": f"invalid JSON: {result.stdout[:200]}"}
        if "error" in data:
            return {"error": data["error"]["message"]}
        charges = data.get("data", [])
        all_charges.extend(charges)
        has_more = data.get("has_more", False)
        if charges:
            starting_after = charges[-1]["id"]
    return all_charges


def fetch_transfers(acct_id, created_gte=None, created_lt=None):
    """Fetch outbound transfers (creator payouts) for marketplace accounts."""
    all_transfers = []
    has_more = True
    starting_after = None
    while has_more:
        url = "https://api.stripe.com/v1/transfers?limit=100"
        if created_gte:
            url += f"&created[gte]={int(created_gte.timestamp())}"
        if created_lt:
            url += f"&created[lt]={int(created_lt.timestamp())}"
        if starting_after:
            url += f"&starting_after={starting_after}"
        result = subprocess.run(
            ["curl", "-s", "-g", url, "-u", f"{stripe_key}:", "-H", f"Stripe-Account: {acct_id}", "-H", "Stripe-Version: 2025-01-27.acacia"],
            capture_output=True, text=True,
        )
        if not result.stdout.strip():
            return []
        try:
            data = json.loads(result.stdout)
        except json.JSONDecodeError:
            return []
        if "error" in data:
            return []
        transfers = data.get("data", [])
        all_transfers.extend(transfers)
        has_more = data.get("has_more", False)
        if transfers:
            starting_after = transfers[-1]["id"]
    return all_transfers


def calc_metrics(charges, transfers=None):
    if isinstance(charges, dict) and "error" in charges:
        return charges
    succeeded = [c for c in charges if c["status"] == "succeeded"]
    gross = sum(c["amount"] for c in succeeded) / 100
    refunded = sum(c.get("amount_refunded", 0) for c in succeeded) / 100
    # Estimate Stripe processing fees: 2.9% + $0.30 per successful txn
    stripe_fees = round(gross * 0.029 + len(succeeded) * 0.30, 2)
    creator_payouts = 0
    if transfers:
        creator_payouts = sum(t["amount"] for t in transfers) / 100
    return {
        "gross_revenue": round(gross, 2),
        "refunds": round(refunded, 2),
        "stripe_fees": stripe_fees,
        "creator_payouts": round(creator_payouts, 2),
        "net_revenue": round(gross - refunded - creator_payouts, 2),  # Match dashboard: no Stripe fee deduction
        "net_after_fees": round(gross - refunded - stripe_fees - creator_payouts, 2),
        "transactions": len(succeeded),
    }


results = {}
total_current = {"gross_revenue": 0, "refunds": 0, "stripe_fees": 0, "creator_payouts": 0, "net_revenue": 0, "transactions": 0}
total_previous = {"gross_revenue": 0, "refunds": 0, "stripe_fees": 0, "creator_payouts": 0, "net_revenue": 0, "transactions": 0}

# Marketplace accounts where gross includes creator payouts
MARKETPLACE_ACCOUNTS = {"claw_mart"}

current_end = end if period == "yesterday" else None
for name, acct_id in ACCOUNTS.items():
    current_charges = fetch_charges(acct_id, start, current_end)
    current_transfers = fetch_transfers(acct_id, start, current_end) if name in MARKETPLACE_ACCOUNTS else None
    current = calc_metrics(current_charges, current_transfers)

    previous = None
    if prev_start:
        prev_charges = fetch_charges(acct_id, prev_start, prev_end)
        prev_transfers = fetch_transfers(acct_id, prev_start, prev_end) if name in MARKETPLACE_ACCOUNTS else None
        previous = calc_metrics(prev_charges, prev_transfers)

    results[name] = {"account_id": acct_id, "current_period": current}
    if previous and "error" not in previous:
        results[name]["previous_period"] = previous

    if "error" not in current:
        for k in total_current:
            total_current[k] = round(total_current[k] + current[k], 2)
    if previous and "error" not in previous:
        for k in total_previous:
            total_previous[k] = round(total_previous[k] + previous[k], 2)

def fetch_felix_cm_earnings(created_gte=None, created_lt=None):
    """Fetch Felix's ClawMart creator earnings from Supabase purchases table."""
    # First get Felix's persona IDs
    r = subprocess.run(
        ["curl", "-s", f"{SUPABASE_URL}/rest/v1/personas?select=id&creator_id=eq.{FELIX_CREATOR_ID}",
         "-H", f"apikey: {SUPABASE_KEY}", "-H", f"Authorization: Bearer {SUPABASE_KEY}"],
        capture_output=True, text=True,
    )
    try:
        persona_ids = [p["id"] for p in json.loads(r.stdout)]
    except:
        return {"gross_revenue": 0, "refunds": 0, "stripe_fees": 0, "creator_payouts": 0, "net_revenue": 0, "transactions": 0}

    if not persona_ids:
        return {"gross_revenue": 0, "refunds": 0, "stripe_fees": 0, "creator_payouts": 0, "net_revenue": 0, "transactions": 0}

    ids_str = ",".join(persona_ids)
    url = f"{SUPABASE_URL}/rest/v1/purchases?select=amount_cents,platform_fee_cents,created_at&persona_id=in.({ids_str})&refunded_at=is.null"
    if created_gte:
        url += f"&created_at=gte.{created_gte.isoformat()}"
    if created_lt:
        url += f"&created_at=lt.{created_lt.isoformat()}"

    r = subprocess.run(
        ["curl", "-s", url, "-H", f"apikey: {SUPABASE_KEY}", "-H", f"Authorization: Bearer {SUPABASE_KEY}"],
        capture_output=True, text=True,
    )
    try:
        purchases = json.loads(r.stdout)
    except:
        return {"gross_revenue": 0, "refunds": 0, "stripe_fees": 0, "creator_payouts": 0, "net_revenue": 0, "transactions": 0}

    gross = sum(p.get("amount_cents", 0) or 0 for p in purchases) / 100
    platform_fees = sum(p.get("platform_fee_cents", 0) or 0 for p in purchases) / 100
    creator_earnings = gross - platform_fees
    return {
        "gross_revenue": round(gross, 2),
        "platform_fees": round(platform_fees, 2),
        "stripe_fees": 0,  # Stripe fees already absorbed by CM Platform account
        "creator_payouts": 0,
        "net_revenue": round(creator_earnings, 2),
        "transactions": len(purchases),
    }

# Felix's ClawMart earnings (from Supabase)
felix_cm_current = fetch_felix_cm_earnings(start, current_end)
felix_cm_previous = fetch_felix_cm_earnings(prev_start, prev_end) if prev_start else None
results["felix_cm_earnings"] = {"source": "supabase", "current_period": felix_cm_current}
if felix_cm_previous:
    results["felix_cm_earnings"]["previous_period"] = felix_cm_previous

output = {
    "period": period,
    "generated_at": now.isoformat(),
    "accounts": results,
    "totals": {"current_period": total_current},
}
if prev_start:
    output["totals"]["previous_period"] = total_previous
    if total_previous["net_revenue"] > 0:
        growth = ((total_current["net_revenue"] - total_previous["net_revenue"]) / total_previous["net_revenue"]) * 100
        output["totals"]["growth_pct"] = round(growth, 1)

print(json.dumps(output, indent=2))
