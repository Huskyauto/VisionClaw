---
name: metrics
description: Pull revenue and business metrics for The Masinov Company across all Stripe accounts. Use when checking daily/weekly/monthly revenue, running the nightly deep dive, comparing periods, or answering any question about sales performance.
---

# Metrics

Pull consolidated revenue metrics across all Masinov Stripe accounts.

## Stripe Revenue

Run the metrics script:

```bash
python3 ~/clawd/skills/metrics/scripts/stripe-metrics.py --period today   # today vs yesterday
python3 ~/clawd/skills/metrics/scripts/stripe-metrics.py --period week    # last 7d vs prior 7d
python3 ~/clawd/skills/metrics/scripts/stripe-metrics.py --period month   # last 30d vs prior 30d
python3 ~/clawd/skills/metrics/scripts/stripe-metrics.py --period all     # all time (no comparison)
```

Output is JSON with per-account and aggregate numbers: gross revenue, refunds, net revenue, transaction count, and period-over-period growth %.

### Accounts Tracked
| Name | Source | Product |
|------|--------|---------|
| claw_mart | Stripe (env: STRIPE_ACCT_CLAW_MART) | Claw Mart marketplace (net = gross - creator payouts) |
| felix_craft | Stripe (env: STRIPE_ACCT_FELIX_CRAFT) | Felix Craft book/site |
| polylogue | Stripe (env: STRIPE_ACCT_POLYLOGUE) | Polylogue |
| felix_cm_earnings | Supabase (purchases table) | Felix's ClawMart creator earnings (gross - platform fees) |

⚠️ **Claw Mart uses NET revenue** (gross minus creator payouts via Stripe transfers). Gross volume includes money paid out to creators — that's not Masinov's revenue.

⚠️ **Felix CM earnings** are pulled from ClawMart Supabase, not Stripe (no access to that Stripe account). All four lines are Masinov revenue and should appear in the same table.

### Nightly Deep Dive Workflow
1. Run `--period today` for the daily snapshot
2. Run `--period month` for trend context
3. **Update the daily Polylogue doc** (workspace: `masinov-dI6MCv`) with final revenue numbers, day recap, and tomorrow's plan
   - Doc title format: "Daily Review — Mon DD, YYYY"
   - Create the doc in the morning if it doesn't exist yet
   - Update at nightly deep dive with final numbers
4. Write findings to `memory/YYYY-MM-DD.md` under "## Revenue Review"
5. Propose next day's plan based on what's working
6. Send Nat a brief Telegram ping that the review is ready (link to Polylogue doc)

### Key Metrics to Track
- **Daily net revenue** — the scoreboard
- **Per-account breakdown** — which products are pulling weight
- **Period growth %** — are we accelerating or decelerating
- **Transaction count** — volume vs ticket size trends

## Claw Mart Admin (Supabase)
Claw Mart data lives in Supabase. Link your project first:

```bash
# Link to the project (one-time)
supabase link --project-ref YOUR_PROJECT_REF

# Query listings, orders, users directly
supabase db query "SELECT * FROM ... LIMIT 10"
```

Use this to check: listing performance, conversion data, what's selling vs what's browsed, inventory gaps.

## Email (Resend)
API key at `~/.config/resend/api_key`. Use for transactional and marketing emails.

```bash
RESEND_KEY=$(cat ~/.config/resend/api_key)
curl -X POST https://api.resend.com/emails \
  -H "Authorization: Bearer $RESEND_KEY" \
  -H "Content-Type: application/json" \
  -d '{"from":"felix@masinov.co","to":"...","subject":"...","html":"..."}'
```

## X/Twitter Scheduling
Use OpenClaw cron jobs with one-shot `at` schedules to post tweets at optimal times via `xpost` CLI.
No external scheduling tool needed — cron + xpost handles it.

## Available Data Sources Summary
| Source | Access | What It Tells Us |
|--------|--------|-----------------|
| Stripe (4 accounts) | ✅ metrics script | Revenue, transactions, trends |
| Supabase (clawd-market) | ✅ supabase CLI | Listings, orders, users, conversion |
| Resend | ✅ API key | Email delivery, engagement |
| X/Twitter | ✅ xpost + bird-felix | Follower growth, engagement, reach |
| Google Search Console | ✅ Service account (`~/.config/google/service-account.json`) | SEO rankings, impressions, clicks |
| Google Analytics | ✅ GA4 property `properties/524863376` (Claw Mart) | Site traffic, behavior, sources |
